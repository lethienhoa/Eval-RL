import torch
from torch import nn
from torch.nn import init
from torch.nn import functional as F

from .attention import step_attention, step_attention_operation_net
from .util import len_mask
from .summ_operation_net_dec_gen_postag import Seq2SeqSummOperationNet, AttentionalLSTMDecoderOperationNet
from . import beam_search as bs
from .rnn import lstm_encoder


INIT = 1e-2


class _CopyLinear(nn.Module):
    def __init__(self, context_dim, state_dim, input_dim, bias=True):
        super().__init__()
        self._v_c = nn.Parameter(torch.Tensor(context_dim))
        self._v_s = nn.Parameter(torch.Tensor(state_dim))
        self._v_i = nn.Parameter(torch.Tensor(input_dim))
        init.uniform_(self._v_c, -INIT, INIT)
        init.uniform_(self._v_s, -INIT, INIT)
        init.uniform_(self._v_i, -INIT, INIT)
        if bias:
            self._b = nn.Parameter(torch.zeros(1))
        else:
            self.regiser_module(None, '_b')
#        self.drop = nn.Dropout(p=0.5)

    def forward(self, context, state, input_):
        output = (torch.matmul(context, self._v_c.unsqueeze(1))
                  + torch.matmul(state, self._v_s.unsqueeze(1))
                  + torch.matmul(input_, self._v_i.unsqueeze(1)))
#        output = self.drop(output)
        if self._b is not None:
            output = output + self._b.unsqueeze(0)
        return output

class CopySummOperationNet(Seq2SeqSummOperationNet):
    def __init__(self, vocab_size, postag_size, emb_dim,
                 n_hidden, bidirectional, n_layer, dropout, coverage):
        super().__init__(vocab_size, postag_size, emb_dim,
                         n_hidden, bidirectional, n_layer, dropout, coverage)
        self._copy = _CopyLinear(n_hidden, n_hidden, 2*emb_dim+30) # 1.
        self._decoder = CopyLSTMDecoderOperationNet(
            self._copy, self._embedding, self._embedding_postag, self._dec_lstm, self._dec_lstm_delete_decoder,
            self._attn_wq, self._projection, self._projection_postag, self._projection_delete_decoder_mask, self._projection_delete_decoder_postag, self._final_projection,
            self._attn_del_out, self.is_coverage, self.W_c, self.cov_loss_wt
        )                                                        # 2.

    def forward(self, article, art_lens, abstract, extend_art, extend_vsize, article_postag, target_postags_in):
        ''' Running in Abstractor (Abstractor Flow 0)'''
        
        # Coverage step 0. Initialize coverave vector
        coverage = None
        if self.is_coverage:
#            print(article.size())
            coverage = torch.zeros(article.size()) # size: B x source_len
            coverage = coverage.cuda()
        
        # Use logit_source_binary to: 1. change attention & 2. compute additional delete_decoder loss
        attention, init_dec_states = self.encode(article, article_postag, art_lens) # Abstractor Flow 1. Seq2Seq2Summ .encode
        
        mask = len_mask(art_lens, attention.device).unsqueeze(-2)
        
#        print("abstract ", abstract)
        # Mask attention by logit_source_binary
        logit = self._decoder(                                      # Abstractor Flow 2. CopyLSTMDecoder(AttentionalLSTMDecoder)
            (attention, mask, extend_art, extend_vsize),
            init_dec_states, article, abstract, target_postags_in, coverage
        )        
        
        return logit

    def batch_decode(self, article, art_lens, extend_art, extend_vsize, article_postag,
                     go, eos, unk, max_len):
        """ greedy decode support batching"""
        ''' Running in Full RL Abstractor (step 4) (we have extracted sentences by RL)'''
        ''' No abstract, unlike forward above '''
        
        # Coverage step 0. Initialize coverave vector
        coverage = None
        if self.is_coverage:
#            print(article.size())
            coverage = torch.zeros(article.size()) # size: B x source_len
            coverage = coverage.cuda()        
        
        batch_size = len(art_lens)
        vsize = self._embedding.num_embeddings
        vsize_postag = self._embedding_postag.num_embeddings
        # modify attention by logit_source_binary here
        attention_tmp, init_dec_states = self.encode(article, article_postag, art_lens) # encode like forward above
        
        mask = len_mask(art_lens, attention_tmp.device).unsqueeze(-2)
        attention = (attention_tmp, mask, extend_art, extend_vsize) # confused name between extend_art & extend_src. actually, there's only extend_src, to extend index of copy net on source with UNK words
        
        # First pass: Decoder Network - still perform like having gold true (source) at test time ----------------------
#        print("article ", article.size(), article)
#        print("target ", target.size(), target)
        max_len = article.size(1)
        states = init_dec_states
        logit_source_binarys = []
        for i in range(max_len): # Decoder: at training time, we go to max_len of target (loop), but then we will mask out decoder padding loss (computation). At test time, we also go to max_len default parameter (loop), then when we convert id2words, we stop when when we see EOS (display). On encoder: we go to enc length
            tok = article[:, i:i+1]
#            print("i ", i, " max_len ", max_len, " tok ", tok)
            logit, states, score, logit_postag, next_coverage = self._decoder._step_delete_decoder(tok, states, attention, coverage) # Abstractor Flow 3. Compute hidden state, context vector, copy, coverage at every time step
            logit_source_binarys.append(logit)
        logit_source_binary = torch.stack(logit_source_binarys, dim=1)        
        
        # Only keep prob of logit_source_binary_keep to compute attention
#        print("logit_source_binary ", logit_source_binary.size(), logit_source_binary)
#        a
#        logit_source_binary  torch.Size([32, 58, 2])
#        (logit_source_binary, None) = logit_source_binary
        prob_source_binary_keep = [[word[1] for word in sent] for sent in torch.exp(logit_source_binary)]
        prob_source_binary_keep = torch.Tensor(prob_source_binary_keep).to(logit_source_binary.device)
        
#        logit_source_binary_keep  torch.Size([32, 58])
#        print("logit_source_binary_keep ", logit_source_binary_keep.size(), logit_source_binary_keep)
#        prob_source_binary_keep = torch.ones(article.size(0), article.size(1)).to(init_dec_states[1].device)
#        prob_source_binary_keep = torch.rand(article.size(0), article.size(1)).to(init_dec_states[1].device)

        
        # Second pass: normal decoder - decode at test time (argmax tok) ----------------------
        attention = (attention_tmp, mask, prob_source_binary_keep, extend_art, extend_vsize)
        
        tok = torch.LongTensor([go]*batch_size).to(article.device)
        tok_postag = torch.LongTensor([go]*batch_size).to(article.device)
        outputs = []
        attns = []
        coverage_loss_seq = []
        states = init_dec_states
        
        for i in range(max_len):
            tok, tok_postag, states, attn_score, next_coverage = self._decoder.decode_step(
                tok, tok_postag, states, attention, coverage) # Running full RL abstractor step 5. Compute hidden state, context vector, copy, coverage at every time step
            attns.append(attn_score)
            outputs.append(tok[:, 0].clone())
            tok.masked_fill_(tok >= vsize, unk)
            tok_postag.masked_fill_(tok_postag >= vsize_postag, unk)
            
            # Coverage step 3. Add coverage loss into NLL loss
            if self.is_coverage:
                # score ~ attn_dist
                # good sign (+/-) in logit
                step_coverage_loss = torch.sum(torch.min(attn_score, coverage), 1) 
                # attn_dist, coverage: B x source_len. torchmin -> smaller value of each B x source_len. torch.sum(dim=1) -> sum all attn_dist min of that sentence <= 1
#                print("logit size", logit.size())
#                print("step_coverage_loss size", step_coverage_loss.size())
                coverage_loss_seq.append(self.cov_loss_wt * step_coverage_loss)
                coverage = next_coverage    
                
        return outputs, attns, coverage


class CopyLSTMDecoderOperationNet(AttentionalLSTMDecoderOperationNet):
    def __init__(self, copy, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._copy = copy
#        self.drop = nn.Dropout(p=0.5)

    def _step_delete_decoder(self, tok, states, attention, coverage):
        ''' Running in Abstractor (Abstractor Flow 3)'''
        prev_states, prev_out = states
#        lstm_in = torch.cat(
#            [self._embedding(tok).squeeze(1), prev_out],
#            dim=1
#        )
        lstm_in = self._embedding(tok).squeeze(1) # don't use prediction t-1 of delete decoder
#        print("self._embedding(tok).squeeze(1) ", self._embedding(tok).squeeze(1).size(), self._embedding(tok).squeeze(1))
#        print("prev_out ", prev_out.size(), prev_out)
#        print("lstm_in ", lstm_in.size(), lstm_in)
#        print("prev_states ", prev_states.size(), prev_states)
#        lstm_in_drop = self.drop(lstm_in)
        states = self._lstm_delete_decoder(lstm_in, prev_states)
        lstm_out = states[0][-1]
        query = torch.mm(lstm_out, self._attn_w) # s_t : decoder hidden state 
        attention, attn_mask, extend_src, extend_vsize = attention
        
        context, score = step_attention(
            query, attention, attention, attn_mask)
        # Operation net: we will only modify score of copy from source (in copy mode) & don't change regular context vector => Only emphasize more on keep source words probability (slight modification of attn distribution)
        
#        print("score ", score.size(), score)
#        print("context ", context.size(), context)
#        a
        dec_out_mask = self._projection_delete_decoder_mask(torch.cat([lstm_out, context], dim=1)) # good shape & dimension ?
        prob_out_mask = F.softmax(dec_out_mask, dim=-1) 
        lp_mask = torch.log(prob_out_mask)  # numerical stability for log
        
        dec_out_postag = self._projection_delete_decoder_postag(torch.cat([lstm_out, context], dim=1))
        prob_out_postag = F.softmax(dec_out_postag, dim=-1) 
        lp_postag = torch.log(prob_out_postag)
        
        return lp_mask, (states, dec_out_mask), score, lp_postag, coverage # replace context as dec_out in (states, dec_out)
    
    
    def _step(self, tok, tok_postag, states, attention, coverage):
        ''' Running in Abstractor (Abstractor Flow 3)'''
        prev_states, prev_out = states
        lstm_in = torch.cat(
            [self._embedding(tok).squeeze(1), self._embedding_postag(tok_postag).squeeze(1), prev_out],
            dim=1
        )
#        print("prev_out ", prev_out.size(), prev_out)
#        lstm_in_drop = self.drop(lstm_in)
        states = self._lstm(lstm_in, prev_states)
        lstm_out = states[0][-1]
        query = torch.mm(lstm_out, self._attn_w) # s_t : decoder hidden state 
        attention, attn_mask, prob_source_binary_keep, extend_src, extend_vsize = attention
#        attention, attn_mask, extend_src, extend_vsize = attention
        
        # Coverage step 1. Put coverage vector into score computation
        if self.is_coverage:
            # good dim ?
            # attention is att_features (encoder inputs)
#            print("coverage size", coverage.size()) # (B, t_k)
            coverage_input = coverage.unsqueeze(2) # (B, t_k, 1)
            coverage_feature = self.W_c(coverage_input) # B * t_k x hidden_size
#            print("coverage_feature size", coverage_feature.size())
#            print("query size", query.size())
#            print("attention", attention.size())
            attention = attention + coverage_feature
        
        context, score = step_attention_operation_net(
            query, attention, attention, prob_source_binary_keep, attn_mask)
#        context, score = step_attention(
#            query, attention, attention, attn_mask)            
        # Operation net: we will only modify score of copy from source (in copy mode) & don't change regular context vector => Only emphasize more on keep source words probability (slight modification of attn distribution)
        
#        print("score ", score.size(), score)
#        print("context ", context.size(), context)
#        a
        dec_out = self._projection(torch.cat([lstm_out, context], dim=1))
#        print("dec_out ", dec_out.size(), dec_out)
#        dec_out  torch.Size([32, 128])
#        a

        # extend generation prob to extended vocabulary
        gen_prob = self._compute_gen_prob(dec_out, extend_vsize) # Abstractor Flow 4
#        print("gen_prob ", gen_prob.size(), gen_prob)
#        gen_prob  torch.Size([32, 30038])
        # compute the probabilty of each copying
        copy_prob = torch.sigmoid(self._copy(context, states[0][-1], lstm_in))
#        print("copy_prob ", copy_prob.size(), copy_prob)
#        copy_prob  torch.Size([32, 1])
#        print("score ", score.size(), score)
#        score  torch.Size([32, 51])
#        a
        # add the copy prob to existing vocab distribution
        lp = torch.log(
            ((-copy_prob + 1) * gen_prob
            ).scatter_add(
                dim=1,
                index=extend_src.expand_as(score),
                source=score * copy_prob
        ) + 1e-8)  # numerical stability for log
        
        dec_out_postag = self._projection_postag(torch.cat([lstm_out, context], dim=1))
        prob_out_postag = F.softmax(dec_out_postag, dim=-1) 
        lp_postag = torch.log(prob_out_postag)        
        
#        print("torch.cat([dec_out, dec_out_postag], dim=1) ", torch.cat([dec_out, dec_out_postag], dim=1).size(), torch.cat([dec_out, dec_out_postag], dim=1))
        final_dec_out = self._final_projection(torch.cat([dec_out, dec_out_postag], dim=1))
#        print("extend_src ", extend_src.size(), extend_src) # like source but use ext_word2id (index can go beyond 30k vocab size)
#        extend_src  torch.Size([32, 30]) 
#        tensor([[    10,   7084,    352,   1794,    209,     38,     19,      4,
#                   3375,    291,     71,      9,      4,    103,    322,      6,
#                   2034,    436,   3033,   3416,   1302,      6,     65,     16,
#                      5,      0,      0,      0,      0,      0],
#                [    10,     26,   5498,      9,   1637,   1808,    434,     14,
#                   3355,   5554,     96,     15,    154,     52,     59,     12,
#                   1104,    128,     66,    261,     10,    370,   2832,    382,
#                      5,      0,      0,      0,      0,      0],
#        print("extend_src.expand_as(score) ", extend_src.expand_as(score).size(), extend_src.expand_as(score))
#        extend_src.expand_as(score)  torch.Size([32, 30]) 
#        tensor([[    10,   7084,    352,   1794,    209,     38,     19,      4,
#                   3375,    291,     71,      9,      4,    103,    322,      6,
#                   2034,    436,   3033,   3416,   1302,      6,     65,     16,
#                      5,      0,      0,      0,      0,      0],
#                [    10,     26,   5498,      9,   1637,   1808,    434,     14,
#                   3355,   5554,     96,     15,    154,     52,     59,     12,
#                   1104,    128,     66,    261,     10,    370,   2832,    382,
#                      5,      0,      0,      0,      0,      0],        
#        print("gen_prob ", gen_prob.size(), gen_prob) # already use extend_vsize, go beyond 30k vocab size
#        gen_prob  torch.Size([32, 30009]) 
#        tensor(1.00000e-04 *
#               [[ 0.3124,  0.2516,  0.3434,  ...,  0.3124,  0.3124,  0.3124],
#                [ 0.3117,  0.2654,  0.4144,  ...,  0.3117,  0.3117,  0.3117],
#        print("copy_prob ", copy_prob.size(), copy_prob)
#        copy_prob  torch.Size([32, 1]) 
#        tensor([[ 0.5108],
#                [ 0.5103],
#                [ 0.5107],
#                [ 0.5105],
#                [ 0.5102],
#                [ 0.5098],
#                [ 0.5107],
#                [ 0.5102],        
#        print("(-copy_prob + 1) * gen_prob ", ((-copy_prob + 1) * gen_prob).size(), (-copy_prob + 1) * gen_prob)
#        (-copy_prob + 1) * gen_prob  torch.Size([32, 30009]) 
#        tensor(1.00000e-05 *
#               [[ 1.5281,  1.2308,  1.6801,  ...,  1.5281,  1.5281,  1.5281],
#                [ 1.5262,  1.2996,  2.0293,  ...,  1.5262,  1.5262,  1.5262],
#        print("score ", score.size(), score)
#        score  torch.Size([32, 30]) 
#        tensor(1.00000e-02 *
#               [[ 3.5495,  3.6468,  3.7109,  3.6641,  4.2257,  4.2084,  4.1851,
#                  4.5518,  4.2073,  4.4779,  3.7853,  3.8277,  4.0565,  3.5247,
#                  3.8667,  3.9640,  4.1002,  4.2233,  3.9107,  4.1987,  4.0328,
#                  3.7907,  3.8506,  4.5123,  3.9282,  0.0000,  0.0000,  0.0000,
#                  0.0000,  0.0000],
#                [ 3.7261,  4.1368,  4.0189,  4.0949,  4.1236,  3.9873,  3.8902,
#                  3.9412,  3.7046,  3.7394,  3.8761,  3.4159,  3.5073,  4.2059,
#                  4.3364,  4.7140,  5.0105,  3.9022,  3.9041,  4.0019,  3.7370,
#                  3.7874,  4.2823,  4.2438,  3.7124,  0.0000,  0.0000,  0.0000,
#                  0.0000,  0.0000],
#        print("score * copy_prob ", (score * copy_prob).size(), score * copy_prob)
#        score * copy_prob  torch.Size([32, 30]) 
#        tensor(1.00000e-02 *
#               [[ 1.8129,  1.8627,  1.8954,  1.8715,  2.1584,  2.1495,  2.1376,
#                  2.3249,  2.1489,  2.2871,  1.9334,  1.9551,  2.0719,  1.8003,
#                  1.9750,  2.0247,  2.0943,  2.1571,  1.9974,  2.1446,  2.0598,
#                  1.9362,  1.9667,  2.3047,  2.0064,  0.0000,  0.0000,  0.0000,
#                  0.0000,  0.0000],
#                [ 1.9014,  2.1110,  2.0509,  2.0897,  2.1043,  2.0348,  1.9852,
#                  2.0112,  1.8905,  1.9082,  1.9780,  1.7431,  1.7898,  2.1463,
#                  2.2129,  2.4056,  2.5569,  1.9913,  1.9923,  2.0422,  1.9070,
#                  1.9327,  2.1853,  2.1657,  1.8945,  0.0000,  0.0000,  0.0000,
#                  0.0000,  0.0000],
#        print("lp ", lp.size(), lp)
#        lp  torch.Size([32, 30009]) 
#        tensor([[-11.0882, -11.3044, -10.9935,  ..., -11.0882, -11.0882, -11.0882],
#                [-11.0895, -11.2501, -10.8048,  ..., -11.0895, -11.0895, -11.0895],
#        a
        
        # Coverage step 2. Sum attn_dist vector at each timestep t to coverage vector
#        print("score size", score.size()) # (32, 13) (B, t_k)
        if self.is_coverage:
            # good dim
#            bat, t_k = list(score.size())
#            coverage = coverage.view(-1, t_k)
            coverage = coverage + score
        
        return lp, (states, final_dec_out), score, lp_postag, copy_prob, coverage

    def _compute_gen_prob(self, dec_out, extend_vsize, eps=1e-6):
        ''' Running in Abstractor (Abstractor Flow 4)'''
        logit = torch.mm(dec_out, self._embedding.weight.t())
        bsize, vsize = logit.size()
        if extend_vsize > vsize:
#            print("logit ", logit[:5])
#            print("bsize ", bsize, " extend_vsize ", extend_vsize, " vsize ", vsize)
            ext_logit = torch.Tensor(bsize, extend_vsize-vsize
                                    ).to(logit.device)
            ext_logit.fill_(eps)
            gen_logit = torch.cat([logit, ext_logit], dim=1)
        else:
            gen_logit = logit
        gen_prob = F.softmax(gen_logit, dim=-1)
        return gen_prob
