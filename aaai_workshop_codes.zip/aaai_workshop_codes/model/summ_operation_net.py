import torch
from torch import nn
from torch.nn import init

from .rnn import lstm_encoder
from .rnn import MultiLayerLSTMCells
from .attention import step_attention
from .util import sequence_mean, len_mask
from torch.nn import functional as F
from torch.autograd import Variable


INIT = 1e-2


class Seq2SeqSummOperationNet(nn.Module):
    def __init__(self, vocab_size, emb_dim,
                 n_hidden, bidirectional, n_layer, dropout, coverage):
        super().__init__()
        # embedding weight parameter is shared between encoder, decoder,
        # and used as final projection layer to vocab logit
        # can initialize with pretrained word vectors
        self._embedding = nn.Embedding(vocab_size, emb_dim, padding_idx=0)
        self._enc_lstm = nn.LSTM(
            emb_dim, n_hidden, n_layer,
            bidirectional=bidirectional, dropout=dropout
        )
        # initial encoder LSTM states are learned parameters
        state_layer = n_layer * (2 if bidirectional else 1)
        self._init_enc_h = nn.Parameter(
            torch.Tensor(state_layer, n_hidden)
        )
        self._init_enc_c = nn.Parameter(
            torch.Tensor(state_layer, n_hidden)
        )
        init.uniform_(self._init_enc_h, -INIT, INIT)
        init.uniform_(self._init_enc_c, -INIT, INIT)

        # vanillat lstm / LNlstm
        self._dec_lstm = MultiLayerLSTMCells(
            2*emb_dim, n_hidden, n_layer, dropout=dropout
        )
        # project encoder final states to decoder initial states
        enc_out_dim = n_hidden * (2 if bidirectional else 1)
        self._dec_h = nn.Linear(enc_out_dim, n_hidden, bias=False)
        self._dec_c = nn.Linear(enc_out_dim, n_hidden, bias=False)
        # multiplicative attention
        self._attn_wm = nn.Parameter(torch.Tensor(enc_out_dim, n_hidden))
        self._attn_wq = nn.Parameter(torch.Tensor(n_hidden, n_hidden))
        init.xavier_normal_(self._attn_wm)
        init.xavier_normal_(self._attn_wq)
        # project decoder output to emb_dim, then
        # apply weight matrix from embedding layer
        self._projection = nn.Sequential(
            nn.Linear(2*n_hidden, n_hidden),
            nn.Tanh(),
            nn.Linear(n_hidden, emb_dim, bias=False)
        )
        self._projection_delete_encoder = nn.Sequential(
            nn.Linear(2*n_hidden, n_hidden),
            nn.Tanh(),
            nn.Linear(n_hidden, 2, bias=False), # To binary prediction 2 classes (0, 1)
            nn.Sigmoid() # nn.Softmax() is wrong here !!!
#            nn.Linear(2*n_hidden, 2),
#            nn.Tanh() # nn.Softmax() is wrong here !!!            
        )   
        self._gate_w = nn.Parameter(torch.Tensor(2*n_hidden, 2*n_hidden))
        self._gate_u = nn.Parameter(torch.Tensor(2*n_hidden, 2*n_hidden))
        self._gate_b = nn.Parameter(torch.Tensor(2*n_hidden))
        
        # Coverage step 0. Init coverage things
        self.is_coverage = coverage
        if self.is_coverage:
            self.W_c = nn.Linear(1, n_hidden, bias=False) # n_hidden * 2 because of Bidirectional encoder   
        else:
            self.W_c = None
        self.cov_loss_wt = 1.0        
        
        # functional object for easier usage
        self._decoder = AttentionalLSTMDecoderOperationNet( # 1.
            self._embedding, self._dec_lstm,
            self._attn_wq, self._projection, self.is_coverage, self.W_c, self.cov_loss_wt
        )
        

#    def forward(self, article, art_lens, abstract):
#        print("Should not run !!!!!!!")
#        attention, init_dec_states = self.encode(article, art_lens)
#        mask = len_mask(art_lens, attention.device).unsqueeze(-2)
#        logit = self._decoder((attention, mask), init_dec_states, abstract)
#        return logit

    def encode(self, article, art_lens=None):
        size = (
            self._init_enc_h.size(0),
            len(art_lens) if art_lens else 1,
            self._init_enc_h.size(1)
        )
        init_enc_states = (
            self._init_enc_h.unsqueeze(1).expand(*size),
            self._init_enc_c.unsqueeze(1).expand(*size)
        )
        enc_art, final_states = lstm_encoder(
            article, self._enc_lstm, art_lens,
            init_enc_states, self._embedding
        )
#        print("enc_art ", enc_art.size(), enc_art)
#        enc_art  torch.Size([25, 32, 512]) 
#        tensor([[[ 0.0982,  0.1839,  0.0422,  ...,  0.0730,  0.2019,  0.0354],
#                 [-0.0771,  0.1172,  0.0150,  ...,  0.1208,  0.1269,  0.0233],
#                 [-0.0165,  0.1200, -0.0902,  ...,  0.2032,  0.0246,  0.0884],
#                 ...,
#                 [-0.0523,  0.0357,  0.0278,  ...,  0.0598,  0.0815, -0.0114],
#                 [ 0.0727, -0.1479, -0.0796,  ..., -0.0250,  0.0201, -0.0620],
#                 [-0.0771,  0.1172,  0.0150,  ...,  0.0917,  0.1702,  0.0197]],   
#                ...     
        
        if self._enc_lstm.bidirectional:
            h, c = final_states
            final_states = (
                torch.cat(h.chunk(2, dim=0), dim=2),
                torch.cat(c.chunk(2, dim=0), dim=2)
            )
        init_h = torch.stack([self._dec_h(s)
                              for s in final_states[0]], dim=0)
        init_c = torch.stack([self._dec_c(s)
                              for s in final_states[1]], dim=0)
        init_dec_states = (init_h, init_c)
#        print("init_h ", init_h.size(), init_h)
#        print("final_states[0] ", final_states[0].size(), final_states[0])
#        print("final_states[1] ", final_states[1].size(), final_states[1])
#        init_h  torch.Size([1, 32, 256])
#        final_states[0]  torch.Size([1, 32, 512])
#        final_states[1]  torch.Size([1, 32, 512])
#        a
        attention = torch.matmul(enc_art, self._attn_wm).transpose(0, 1) # Here is not really attention, just a bank of enc hidden states to compute attention
#        print("attention ", attention.size(), attention)
#        attention  torch.Size([32, 25, 256])
#        print("sequence_mean(attention, art_lens, dim=1)", sequence_mean(attention, art_lens, dim=1).size(), sequence_mean(attention, art_lens, dim=1))
#        sequence_mean(attention, art_lens, dim=1) torch.Size([32, 256])
        
        init_attn_out = self._projection(torch.cat(
            [init_h[-1], sequence_mean(attention, art_lens, dim=1)], dim=1
        ))
#        print("init_attn_out ", init_attn_out.size(), init_attn_out)
#        init_attn_out  torch.Size([32, 128])
        
        # --------------
        # logit out to binary prediction 2 classes (0, 1). We will mask out padding token later in the loss calculation
        #        enc_art = enc_art.view(enc_art.size(1), enc_art.size(0), enc_art.size(2)) # Wrong to solve batch_first=False problem (didn't convert words first into batch first)
        sent_representation = final_states[0].squeeze(0) # hidden state torch.Size([1, 32, 512]) -> torch.Size([32, 512])
#        global_enc_art = Variable(enc_art.data, requires_grad=True).to(enc_art.device) # torch.Size([25, 32, 512]). true way to copy value & detach grad history. Wrong: var.clone(): copy data & link grad history
        global_enc_art = []
#        print("global_enc_art ", global_enc_art.size(), global_enc_art)
        for i in range(enc_art.size(0)): # loop by each word : [32, 512]
#            print("enc_art[i,:,:].unsqueeze(0) ", enc_art[i,:,:].unsqueeze(0).size(), enc_art[i,:,:].unsqueeze(0))
#            print("torch.matmul(enc_art[i,:,:], self._gate_w) ", torch.matmul(enc_art[i,:,:], self._gate_w).size(), torch.matmul(enc_art[i,:,:], self._gate_w))
#            print("torch.matmul(sent_representation, self._gate_u) ", torch.matmul(sent_representation, self._gate_u).size(), torch.matmul(sent_representation, self._gate_u))
#            print("self._gate_b ", self._gate_b.size(), self._gate_b)
            sGate_i = torch.matmul(enc_art[i,:,:], self._gate_w) + torch.matmul(sent_representation, self._gate_u) # + self._gate_b : nan, why ?
#            print("sGate_i ", sGate_i.size(), sGate_i) # [32, 512]
            sGate_i = torch.sigmoid(sGate_i) # sigmoid on each value (don't need dimension)
#            print("sGate_i ", sGate_i.size(), sGate_i)
            global_enc_art.append(enc_art[i,:,:].mul(sGate_i)) # var_a.mul(var_b) element wise multiplication vs. torch.matmul(var_a, var_b): matrix multiplication
#            print("global_enc_art[i,:,:] ", global_enc_art[i,:,:].size(), global_enc_art[i,:,:])
#            a
        global_enc_art = torch.stack(global_enc_art)
#        print("global_enc_art ", global_enc_art.size(), global_enc_art)
#        a        
        dec_out = self._projection_delete_encoder(torch.transpose(global_enc_art, 0, 1))    # Get back to batch_size first: torch.Size([32, 25, 512]). Torch.transpose is right to solve batch_first=False problem !!!
        prob_delete_encode = F.softmax(dec_out, dim=-1)
#        print("prob_delete_encode ", prob_delete_encode.size(), prob_delete_encode)
#        logit_delete_encode  
#        torch.Size([32, 25, 2]) 
#        tensor([[[ 0.4972,  0.5028],
#                 [ 0.4976,  0.5024],
#                 [ 0.4980,  0.5020],
#                 ...,
#                 [ 0.4998,  0.5002],
#                 [ 0.4998,  0.5002],
#                 [ 0.4998,  0.5002]],
#        a
        
        return attention, (init_dec_states, init_attn_out), prob_delete_encode
    
#    def batch_decode(self, article, art_lens, go, eos, max_len):
#        """ greedy decode support batching"""
#        
#        print("Should not run !!!!!!!")
#        batch_size = len(art_lens)
#        attention, init_dec_states = self.encode(article, art_lens)
#        mask = len_mask(art_lens, attention.device).unsqueeze(-2)
#        attention = (attention, mask)
#        tok = torch.LongTensor([go]*batch_size).to(article.device)
#        outputs = []
#        attns = []
#        states = init_dec_states
#        for i in range(max_len):
#            tok, states, attn_score = self._decoder.decode_step(
#                tok, states, attention)
#            outputs.append(tok[:, 0])
#            attns.append(attn_score)
#        return outputs, attns

#    def decode(self, article, go, eos, max_len):
#        print("Should not run !!!!!!!")
#        attention, init_dec_states = self.encode(article)
#        attention = (attention, None)
#        tok = torch.LongTensor([go]).to(article.device)
#        outputs = []
#        attns = []
#        states = init_dec_states
#        for i in range(max_len):
#            tok, states, attn_score = self._decoder.decode_step(
#                tok, states, attention)
#            if tok[0, 0].item() == eos:
#                break
#            outputs.append(tok[0, 0].item())
#            attns.append(attn_score.squeeze(0))
#        return outputs, attns
#
#    def set_embedding(self, embedding):
#        """embedding is the weight matrix"""
#        assert self._embedding.weight.size() == embedding.size()
#        self._embedding.weight.data.copy_(embedding)


class AttentionalLSTMDecoderOperationNet(object):
    def __init__(self, embedding, lstm, attn_w, projection, coverage, W_c, cov_loss_wt):
        super().__init__()
        self._embedding = embedding
        self._lstm = lstm
        self._attn_w = attn_w
        self._projection = projection
        self.is_coverage = coverage
        self.W_c = W_c
        self.cov_loss_wt = cov_loss_wt

    def __call__(self, attention, init_states, target, coverage):
        ''' Running in Abstractor (Abstractor Flow 2)'''
        
        max_len = target.size(1)
        states = init_states
        logits = []
        coverage_loss_seq = []
        for i in range(max_len): # Decoder: at training time, we still go to max_len (loop), but then we will mask out decoder padding loss (computation). At test time, we also go to max_len (loop), then when we convert id2words, we stop when when we see EOS (display). On encoder: we go to enc length
            tok = target[:, i:i+1]
#            print("i ", i, " max_len ", max_len, " tok ", tok)
            logit, states, score, next_coverage = self._step(tok, states, attention, coverage) # Abstractor Flow 3. Compute hidden state, context vector, copy, coverage at every time step
            
            # Coverage step 3. Add coverage loss into NLL loss
            if self.is_coverage:
                # score ~ attn_dist
                # good sign (+/-) in logit
                step_coverage_loss = torch.sum(torch.min(score, coverage), 1) 
                # attn_dist, coverage: B x source_len. torchmin -> smaller value of each B x source_len. torch.sum(dim=1) -> sum all attn_dist min of that sentence <= 1
#                print("logit size", logit.size())
#                print("step_coverage_loss size", step_coverage_loss.size())
                coverage_loss_seq.append(self.cov_loss_wt * step_coverage_loss)
                coverage = next_coverage
            
            logits.append(logit)
        logit = torch.stack(logits, dim=1)
        if coverage_loss_seq:
            coverage_loss = torch.stack(coverage_loss_seq, dim=1)
        else:
            coverage_loss = None
        
        return logit, coverage_loss

#    def _step(self, tok, states, attention):
#        print("Should not run !!!!!!!")
#        prev_states, prev_out = states
#        lstm_in = torch.cat(
#            [self._embedding(tok).squeeze(1), prev_out],
#            dim=1
#        )
#        states = self._lstm(lstm_in, prev_states)
#        lstm_out = states[0][-1]
#        query = torch.mm(lstm_out, self._attn_w)
#        attention, attn_mask = attention
#        context, score = step_attention(
#            query, attention, attention, attn_mask)
#        dec_out = self._projection(torch.cat([lstm_out, context], dim=1))
#        states = (states, dec_out)
#        logit = torch.mm(dec_out, self._embedding.weight.t())
#        return logit, states, score

    def decode_step(self, tok, states, attention, coverage): # Coverage Full RL step 2.
        ''' Running in Full RL Abstractor (step 5)'''
        
        logit, states, score, coverage = self._step(tok, states, attention, coverage) # Running full step 6.
        out = torch.max(logit, dim=1, keepdim=True)[1]
        return out, states, score, coverage
