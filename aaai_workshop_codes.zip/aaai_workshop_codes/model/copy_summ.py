import torch
from torch import nn
from torch.nn import init
from torch.nn import functional as F

from .attention import step_attention
from .util import len_mask
from .summ import Seq2SeqSumm, AttentionalLSTMDecoder
from . import beam_search as bs


INIT = 1e-2


class _CopyLinear(nn.Module):
    def __init__(self, context_dim, state_dim, input_dim, bias=True):
        super().__init__()
        self._v_c = nn.Parameter(torch.Tensor(context_dim))
        self._v_s = nn.Parameter(torch.Tensor(state_dim))
        self._v_i = nn.Parameter(torch.Tensor(input_dim))
        init.uniform_(self._v_c, -INIT, INIT)
        init.uniform_(self._v_s, -INIT, INIT)
        init.uniform_(self._v_i, -INIT, INIT)
        if bias:
            self._b = nn.Parameter(torch.zeros(1))
        else:
            self.regiser_module(None, '_b')
#        self.drop = nn.Dropout(p=0.5)

    def forward(self, context, state, input_):
        output = (torch.matmul(context, self._v_c.unsqueeze(1))
                  + torch.matmul(state, self._v_s.unsqueeze(1))
                  + torch.matmul(input_, self._v_i.unsqueeze(1)))
#        output = self.drop(output)
        if self._b is not None:
            output = output + self._b.unsqueeze(0)
        return output


class CopySumm(Seq2SeqSumm):
    def __init__(self, vocab_size, emb_dim,
                 n_hidden, bidirectional, n_layer, dropout, coverage):
        super().__init__(vocab_size, emb_dim,
                         n_hidden, bidirectional, n_layer, dropout, coverage)
        self._copy = _CopyLinear(n_hidden, n_hidden, 2*emb_dim) # 1.
        self._decoder = CopyLSTMDecoder(
            self._copy, self._embedding, self._dec_lstm,
            self._attn_wq, self._projection, self.is_coverage, self.W_c, self.cov_loss_wt
        )                                                       # 2.

    def forward(self, article, art_lens, abstract, extend_art, extend_vsize):
        ''' Running in Abstractor (Abstractor Flow 0)'''
        # abstract ?
        # extend_art ?
        
        # Coverage step 0. Initialize coverave vector
        coverage = None
        if self.is_coverage:
#            print(article.size())
            coverage = torch.zeros(article.size()) # size: B x source_len
            coverage = coverage.cuda()
            
        attention, init_dec_states = self.encode(article, art_lens) # Abstractor Flow 1. Seq2Seq2Summ .encode
#        print("attention ", attention, "attention size", attention.size)
#        print("init_dec_states ", init_dec_states)
        mask = len_mask(art_lens, attention.device).unsqueeze(-2)
#        print("abstract ", abstract)
        logit = self._decoder(                                      # Abstractor Flow 2. CopyLSTMDecoder(AttentionalLSTMDecoder)
            (attention, mask, extend_art, extend_vsize),
            init_dec_states, abstract, coverage
        )
        return logit

    def batch_decode(self, article, art_lens, extend_art, extend_vsize,
                     go, eos, unk, max_len):
        """ greedy decode support batching"""
        ''' Running in Full RL Abstractor (step 4) (we have extracted sentences by RL)'''
        ''' No abstract, unlike forward above '''
        
        # Coverage step 0. Initialize coverave vector
        coverage = None
        if self.is_coverage:
#            print(article.size())
            coverage = torch.zeros(article.size()) # size: B x source_len
            coverage = coverage.cuda()        
        
        batch_size = len(art_lens)
        vsize = self._embedding.num_embeddings
        attention, init_dec_states = self.encode(article, art_lens) # encode like forward above
        
        mask = len_mask(art_lens, attention.device).unsqueeze(-2)
        attention = (attention, mask, extend_art, extend_vsize)
        tok = torch.LongTensor([go]*batch_size).to(article.device)
        outputs = []
        attns = []
        coverage_loss_seq = []
        states = init_dec_states
        
        for i in range(max_len):
            tok, states, attn_score, next_coverage = self._decoder.decode_step(
                tok, states, attention, coverage) # Running full RL abstractor step 5. Compute hidden state, context vector, copy, coverage at every time step
            attns.append(attn_score)
            outputs.append(tok[:, 0].clone())
            tok.masked_fill_(tok >= vsize, unk)
            
            # Coverage step 3. Add coverage loss into NLL loss
            if self.is_coverage:
                # score ~ attn_dist
                # good sign (+/-) in logit
                step_coverage_loss = torch.sum(torch.min(attn_score, coverage), 1) 
                # attn_dist, coverage: B x source_len. torchmin -> smaller value of each B x source_len. torch.sum(dim=1) -> sum all attn_dist min of that sentence <= 1
#                print("logit size", logit.size())
#                print("step_coverage_loss size", step_coverage_loss.size())
                coverage_loss_seq.append(self.cov_loss_wt * step_coverage_loss)
                coverage = next_coverage    
                
        return outputs, attns, coverage

    def decode(self, article, extend_art, extend_vsize, go, eos, unk, max_len):
        print("Should not run !!!!!!!")
        vsize = self._embedding.num_embeddings
        attention, init_dec_states = self.encode(article)
        attention = (attention, None, extend_art, extend_vsize)
        tok = torch.LongTensor([go]).to(article.device)
        outputs = []
        attns = []
        states = init_dec_states
        for i in range(max_len):
            tok, states, attn_score = self._decoder.decode_step(
                tok, states, attention)
            if tok[0, 0].item() == eos:
                break
            outputs.append(tok[0, 0].item())
            attns.append(attn_score.squeeze(0))
            if tok[0, 0].item() >= vsize:
                tok[0, 0] = unk
        return outputs, attns

    def batched_beamsearch(self, article, art_lens,
                           extend_art, extend_vsize,
                           go, eos, unk, max_len, beam_size, diverse=1.0):
        print("Should not run !!!!!!!")
        batch_size = len(art_lens)
        vsize = self._embedding.num_embeddings
        attention, init_dec_states = self.encode(article, art_lens)
        mask = len_mask(art_lens, attention.device).unsqueeze(-2)
        all_attention = (attention, mask, extend_art, extend_vsize)
        attention = all_attention
        (h, c), prev = init_dec_states
        all_beams = [bs.init_beam(go, (h[:, i, :], c[:, i, :], prev[i]))
                     for i in range(batch_size)]
        finished_beams = [[] for _ in range(batch_size)]
        outputs = [None for _ in range(batch_size)]
        for t in range(max_len):
            toks = []
            all_states = []
            for beam in filter(bool, all_beams):
                token, states = bs.pack_beam(beam, article.device)
                toks.append(token)
                all_states.append(states)
            token = torch.stack(toks, dim=1)
            states = ((torch.stack([h for (h, _), _ in all_states], dim=2),
                       torch.stack([c for (_, c), _ in all_states], dim=2)),
                      torch.stack([prev for _, prev in all_states], dim=1))
            token.masked_fill_(token >= vsize, unk)

            topk, lp, states, attn_score = self._decoder.topk_step(
                token, states, attention, beam_size)

            batch_i = 0
            for i, (beam, finished) in enumerate(zip(all_beams,
                                                     finished_beams)):
                if not beam:
                    continue
                finished, new_beam = bs.next_search_beam(
                    beam, beam_size, finished, eos,
                    topk[:, batch_i, :], lp[:, batch_i, :],
                    (states[0][0][:, :, batch_i, :],
                     states[0][1][:, :, batch_i, :],
                     states[1][:, batch_i, :]),
                    attn_score[:, batch_i, :],
                    diverse
                )
                batch_i += 1
                if len(finished) >= beam_size:
                    all_beams[i] = []
                    outputs[i] = finished[:beam_size]
                    # exclude finished inputs
                    (attention, mask, extend_art, extend_vsize
                    ) = all_attention
                    masks = [mask[j] for j, o in enumerate(outputs)
                             if o is None]
                    ind = [j for j, o in enumerate(outputs) if o is None]
                    ind = torch.LongTensor(ind).to(attention.device)
                    attention, extend_art = map(
                        lambda v: v.index_select(dim=0, index=ind),
                        [attention, extend_art]
                    )
                    if masks:
                        mask = torch.stack(masks, dim=0)
                    else:
                        mask = None
                    attention = (
                        attention, mask, extend_art, extend_vsize)
                else:
                    all_beams[i] = new_beam
                    finished_beams[i] = finished
            if all(outputs):
                break
        else:
            for i, (o, f, b) in enumerate(zip(outputs,
                                              finished_beams, all_beams)):
                if o is None:
                    outputs[i] = (f+b)[:beam_size]
        return outputs


class CopyLSTMDecoder(AttentionalLSTMDecoder):
    def __init__(self, copy, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._copy = copy
#        self.drop = nn.Dropout(p=0.5)

    def _step(self, tok, states, attention, coverage):
        ''' Running in Abstractor (Abstractor Flow 3)'''
        prev_states, prev_out = states
        lstm_in = torch.cat(
            [self._embedding(tok).squeeze(1), prev_out],
            dim=1
        )
#        lstm_in_drop = self.drop(lstm_in)
        states = self._lstm(lstm_in, prev_states)
        lstm_out = states[0][-1]
        query = torch.mm(lstm_out, self._attn_w) # s_t : decoder hidden state 
        attention, attn_mask, extend_src, extend_vsize = attention
        
        # Coverage step 1. Put coverage vector into score computation
        if self.is_coverage:
            # good dim ?
            # attention is att_features (encoder inputs)
#            print("coverage size", coverage.size()) # (B, t_k)
            coverage_input = coverage.unsqueeze(2) # (B, t_k, 1)
            coverage_feature = self.W_c(coverage_input) # B * t_k x hidden_size
#            print("coverage_feature size", coverage_feature.size())
#            print("query size", query.size())
#            print("attention", attention.size())
            attention = attention + coverage_feature
        
        context, score = step_attention(
            query, attention, attention, attn_mask)
#        print("lstm_out ", lstm_out[:1], " lstm_out size ", lstm_out.size())
#        print("context ", context[:1], " context size ", context.size())
        dec_out = self._projection(torch.cat([lstm_out, context], dim=1))
#        print("dec_out ", dec_out[:5], " dec_out size ", dec_out.size())

        # extend generation prob to extended vocabulary
        gen_prob = self._compute_gen_prob(dec_out, extend_vsize) # Abstractor Flow 4
        # compute the probabilty of each copying
        copy_prob = torch.sigmoid(self._copy(context, states[0][-1], lstm_in))
        # add the copy prob to existing vocab distribution
        lp = torch.log(
            ((-copy_prob + 1) * gen_prob
            ).scatter_add(
                dim=1,
                index=extend_src.expand_as(score),
                source=score * copy_prob
        ) + 1e-8)  # numerical stability for log
        
        # Coverage step 2. Sum attn_dist vector at each timestep t to coverage vector
#        print("score size", score.size()) # (32, 13) (B, t_k)
        if self.is_coverage:
            # good dim
#            bat, t_k = list(score.size())
#            coverage = coverage.view(-1, t_k)
            coverage = coverage + score
        
        return lp, (states, dec_out), score, coverage


    def topk_step(self, tok, states, attention, k):
        """tok:[BB, B], states ([L, BB, B, D]*2, [BB, B, D])"""
        
        print("Should not run !!!!!!!")
        (h, c), prev_out = states

        # lstm is not bemable
        nl, _, _, d = h.size()
        beam, batch = tok.size()
        lstm_in_beamable = torch.cat(
            [self._embedding(tok), prev_out], dim=-1)
        lstm_in = lstm_in_beamable.contiguous().view(beam*batch, -1)
        prev_states = (h.contiguous().view(nl, -1, d),
                       c.contiguous().view(nl, -1, d))
        h, c = self._lstm(lstm_in, prev_states)
        states = (h.contiguous().view(nl, beam, batch, -1),
                  c.contiguous().view(nl, beam, batch, -1))
        lstm_out = states[0][-1]

        # attention is beamable
        query = torch.matmul(lstm_out, self._attn_w)
        attention, attn_mask, extend_src, extend_vsize = attention
        context, score = step_attention(
            query, attention, attention, attn_mask)
        dec_out = self._projection(torch.cat([lstm_out, context], dim=-1))

        # copy mechanism is not beamable
        gen_prob = self._compute_gen_prob(
            dec_out.contiguous().view(batch*beam, -1), extend_vsize)
        copy_prob = torch.sigmoid(
            self._copy(context, lstm_out, lstm_in_beamable)
        ).contiguous().view(-1, 1)
        lp = torch.log(
            ((-copy_prob + 1) * gen_prob
            ).scatter_add(
                dim=1,
                index=extend_src.expand_as(score).contiguous().view(
                    beam*batch, -1),
                source=score.contiguous().view(beam*batch, -1) * copy_prob
        ) + 1e-8).contiguous().view(beam, batch, -1)

        k_lp, k_tok = lp.topk(k=k, dim=-1)
        return k_tok, k_lp, (states, dec_out), score

    def _compute_gen_prob(self, dec_out, extend_vsize, eps=1e-6):
        ''' Running in Abstractor (Abstractor Flow 4)'''
        logit = torch.mm(dec_out, self._embedding.weight.t())
        bsize, vsize = logit.size()
        if extend_vsize > vsize:
#            print("logit ", logit[:5])
#            print("bsize ", bsize, " extend_vsize ", extend_vsize, " vsize ", vsize)
            ext_logit = torch.Tensor(bsize, extend_vsize-vsize
                                    ).to(logit.device)
            ext_logit.fill_(eps)
            gen_logit = torch.cat([logit, ext_logit], dim=1)
        else:
            gen_logit = logit
        gen_prob = F.softmax(gen_logit, dim=-1)
        return gen_prob

    def _compute_copy_activation(self, context, state, input_, score):
        copy = self._copy(context, state, input_) * score
        return copy
