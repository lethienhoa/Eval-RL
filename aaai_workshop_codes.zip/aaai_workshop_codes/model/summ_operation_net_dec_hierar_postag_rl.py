import torch
from torch import nn
from torch.nn import init

from .rnn_gen_postag import lstm_encoder_normal, lstm_encoder_postag
from .rnn_gen_postag import MultiLayerLSTMCells
from .attention import step_attention
from .util import sequence_mean, len_mask
from torch.nn import functional as F
from torch.autograd import Variable
from utils import PAD, UNK, START, END


INIT = 1e-2


class Seq2SeqSummOperationNet(nn.Module):
    def __init__(self, vocab_size, postag_size, deptag_size, nertag_size, emb_dim,
                 n_hidden, bidirectional, n_layer, dropout, coverage):
        super().__init__()
        # embedding weight parameter is shared between encoder, decoder,
        # and used as final projection layer to vocab logit
        # can initialize with pretrained word vectors
        self._embedding = nn.Embedding(vocab_size, emb_dim, padding_idx=0)
        self._embedding_postag = nn.Embedding(postag_size, 30, padding_idx=0)
        self._embedding_deptag = nn.Embedding(deptag_size, 30, padding_idx=0)
        self._embedding_nertag = nn.Embedding(nertag_size, emb_dim, padding_idx=0)
        self._enc_lstm = nn.LSTM(
            1*emb_dim, n_hidden, n_layer,
            bidirectional=bidirectional, dropout=dropout
        )
        self._enc_lstm_postag = nn.LSTM(
            30, 64, n_layer,
            bidirectional=bidirectional, dropout=dropout
        )     
        self._enc_lstm_deptag = nn.LSTM(
            30, 64, n_layer,
            bidirectional=bidirectional, dropout=dropout
        )           
        # initial encoder LSTM states are learned parameters
        state_layer = n_layer * (2 if bidirectional else 1)
        self._init_enc_h = nn.Parameter(
            torch.Tensor(state_layer, n_hidden)
        )
        self._init_enc_c = nn.Parameter(
            torch.Tensor(state_layer, n_hidden)
        )
        self._init_enc_h_postag = nn.Parameter(
            torch.Tensor(state_layer, 64)
        )
        self._init_enc_c_postag = nn.Parameter(
            torch.Tensor(state_layer, 64)
        )        
        self._init_enc_h_deptag = nn.Parameter(
            torch.Tensor(state_layer, 64)
        )
        self._init_enc_c_deptag = nn.Parameter(
            torch.Tensor(state_layer, 64)
        )         
        init.uniform_(self._init_enc_h, -INIT, INIT)
        init.uniform_(self._init_enc_c, -INIT, INIT)
        init.uniform_(self._init_enc_h_postag, -INIT, INIT)
        init.uniform_(self._init_enc_c_postag, -INIT, INIT)      
        init.uniform_(self._init_enc_h_deptag, -INIT, INIT)
        init.uniform_(self._init_enc_c_deptag, -INIT, INIT)          

        # vanillat lstm / LNlstm
        self._dec_lstm = MultiLayerLSTMCells(
            2*emb_dim, n_hidden, n_layer, dropout=dropout
        )     
        self._dec_lstm_delete_decoder = MultiLayerLSTMCells(
            emb_dim, n_hidden, n_layer, dropout=dropout # take only input
        )        
        # project encoder final states to decoder initial states
        enc_out_dim = n_hidden * (2 if bidirectional else 1)
        self._dec_h = nn.Linear(enc_out_dim, n_hidden, bias=False)
        self._dec_c = nn.Linear(enc_out_dim, n_hidden, bias=False)
        # multiplicative attention
        self._attn_wm = nn.Parameter(torch.Tensor(enc_out_dim, n_hidden))
        self._attn_wq = nn.Parameter(torch.Tensor(n_hidden, n_hidden))
        init.xavier_normal_(self._attn_wm)
        init.xavier_normal_(self._attn_wq)
        # project decoder output to emb_dim, then
        # apply weight matrix from embedding layer
        self._projection = nn.Sequential(
            nn.Linear(2*n_hidden, n_hidden),
            nn.Tanh(),
            nn.Linear(n_hidden, emb_dim, bias=False)
        )
        self._projection_postag = nn.Sequential(
            nn.Linear(2*n_hidden, n_hidden),
            nn.Tanh(),
            nn.Linear(n_hidden, postag_size, bias=False)
        )        
        self._projection_delete_decoder_mask = nn.Sequential(
            nn.Linear(2*n_hidden, n_hidden),
            nn.Tanh(),
            nn.Linear(n_hidden, 2, bias=False), # To binary prediction 2 classes (0, 1)
#            nn.Linear(2*n_hidden, 2),
#            nn.Tanh() # nn.Softmax() is wrong here !!!            
        )   
        self._projection_delete_decoder_postag = nn.Sequential(
            nn.Linear(2*n_hidden, n_hidden),
            nn.Tanh(),
            nn.Linear(n_hidden, postag_size, bias=False)
        )
        self._final_projection = nn.Linear(emb_dim+postag_size, emb_dim)      
        self._attn_del_out = nn.Parameter(torch.Tensor(emb_dim, 2))
        
        # Coverage step 0. Init coverage things
        self.is_coverage = coverage
        if self.is_coverage:
            self.W_c = nn.Linear(1, n_hidden, bias=False) # n_hidden * 2 because of Bidirectional encoder   
        else:
            self.W_c = None
        self.cov_loss_wt = 1.0        
        
        # functional object for easier usage
        self._decoder = AttentionalLSTMDecoderOperationNet( # 1.
            self._embedding, self._embedding_postag, self._dec_lstm, self._dec_lstm_delete_decoder, self._attn_wq, 
            self._projection, self._projection_postag, 
            self._projection_delete_decoder_mask, self._projection_delete_decoder_postag, self._final_projection,
            self._attn_del_out, self.is_coverage, self.W_c, self.cov_loss_wt
        )
        

#    def forward(self, article, art_lens, abstract):
#        print("Should not run !!!!!!!")
#        attention, init_dec_states = self.encode(article, art_lens)
#        mask = len_mask(art_lens, attention.device).unsqueeze(-2)
#        logit = self._decoder((attention, mask), init_dec_states, abstract)
#        return logit

    def encode(self, article, article_postag, article_deptag, article_nertag, art_lens=None):
        size = (
            self._init_enc_h.size(0),
            len(art_lens) if art_lens else 1,
            self._init_enc_h.size(1)
        )
        init_enc_states = (
            self._init_enc_h.unsqueeze(1).expand(*size),
            self._init_enc_c.unsqueeze(1).expand(*size)
        )
        size_postag = (
            self._init_enc_h_postag.size(0),
            len(art_lens) if art_lens else 1,
            self._init_enc_h_postag.size(1)
        )        
        init_enc_states_postag = (
            self._init_enc_h_postag.unsqueeze(1).expand(*size_postag),
            self._init_enc_c_postag.unsqueeze(1).expand(*size_postag)
        )    
        size_deptag = (
            self._init_enc_h_deptag.size(0),
            len(art_lens) if art_lens else 1,
            self._init_enc_h_deptag.size(1)
        )        
        init_enc_states_deptag = (
            self._init_enc_h_deptag.unsqueeze(1).expand(*size_deptag),
            self._init_enc_c_deptag.unsqueeze(1).expand(*size_deptag)
        )          
#        print("article ", article.size(), article)
#        print("article_postag ", article_postag.size(), article_postag)
#        print("article_deptag ", article_deptag.size(), article_deptag)
#        print("article_nertag ", article_nertag.size(), article_nertag)
#        a
#        article  torch.Size([32, 39]) 
#        tensor([[    21,    265,     13,  ...,      0,      0,      0],
#                [  1507,     12,  28409,  ...,      0,      0,      0],
#                [    47,     35,    355,  ...,      0,      0,      0],
#                ...,
#                [    94,   1168,     58,  ...,      7,   8855,      5],
#                [   255,    853,      8,  ...,     11,     32,      5],
#                [    10,   3936,    380,  ...,     11,     36,      5]], device='cuda:0')
#        article_postag  torch.Size([32, 39]) 
#        tensor([[  9,  15,  20,  ...,   0,   0,   0],
#                [ 15,   4,  16,  ...,   0,   0,   0],
#                [ 21,  15,  15,  ...,   0,   0,   0],
#                ...,
#                [ 10,  16,  34,  ...,  28,  15,   1],
#                [ 15,  16,   9,  ...,   9,  17,   1],
#                [  6,  15,  32,  ...,   9,  17,   1]], device='cuda:0')
#        a

        # Postag RNN Encoder
#        enc_deptag, _ = lstm_encoder_normal(
#            article_deptag, self._enc_lstm_deptag, art_lens,
#            init_enc_states_deptag, self._embedding_deptag
#        )       
#        enc_postag, _ = lstm_encoder_normal(
#            article_postag, self._enc_lstm_postag, art_lens,
#            init_enc_states_postag, self._embedding_postag
#        )        
#        enc_postag, _ = lstm_encoder_postag(
#            article_postag, enc_deptag, enc_deptag, enc_deptag, self._enc_lstm_postag, art_lens,
#            init_enc_states_postag, self._embedding_postag, self._embedding_postag, self._embedding_postag
#        )        
#        print("enc_postag ", enc_postag.size(), enc_postag)
#        enc_postag  torch.Size([58, 32, 512])
        
        # Word RNN Encoder
        enc_art, final_states = lstm_encoder_postag(
            article, article, article, article, self._enc_lstm, art_lens,
            init_enc_states, self._embedding, self._embedding, self._embedding
        )
        
        dec_out_postag = self._projection_delete_decoder_postag(torch.transpose(enc_art, 0, 1))
        prob_out_postag = F.softmax(dec_out_postag, dim=-1) 
        lp_postag = torch.log(prob_out_postag)
        
#        print("enc_art ", enc_art.size(), enc_art)
#        enc_art  torch.Size([64, 32, 512])
#        a
#        enc_art  torch.Size([25, 32, 512]) 
#        tensor([[[ 0.0982,  0.1839,  0.0422,  ...,  0.0730,  0.2019,  0.0354],
#                 [-0.0771,  0.1172,  0.0150,  ...,  0.1208,  0.1269,  0.0233],
#                 [-0.0165,  0.1200, -0.0902,  ...,  0.2032,  0.0246,  0.0884],
#                 ...,
#                 [-0.0523,  0.0357,  0.0278,  ...,  0.0598,  0.0815, -0.0114],
#                 [ 0.0727, -0.1479, -0.0796,  ..., -0.0250,  0.0201, -0.0620],
#                 [-0.0771,  0.1172,  0.0150,  ...,  0.0917,  0.1702,  0.0197]],   
#                ...           
#        print("final_states[0] ", final_states[0].size(), final_states[0])
#        final_states[0]  torch.Size([2, 32, 256])
#        print("final_states[1] ", final_states[1].size(), final_states[1])
#        final_states[1]  torch.Size([2, 32, 256])
        
        if self._enc_lstm.bidirectional:
            h, c = final_states
            final_states = (
                torch.cat(h.chunk(2, dim=0), dim=2),
                torch.cat(c.chunk(2, dim=0), dim=2)
            )
        init_h = torch.stack([self._dec_h(s)
                              for s in final_states[0]], dim=0)
        init_c = torch.stack([self._dec_c(s)
                              for s in final_states[1]], dim=0)
        init_dec_states = (init_h, init_c)
#        print("init_h ", init_h.size(), init_h)
#        print("final_states[0] ", final_states[0].size(), final_states[0])
#        print("final_states[1] ", final_states[1].size(), final_states[1])
#        init_h  torch.Size([1, 32, 256])
#        final_states[0]  torch.Size([1, 32, 512])
#        final_states[1]  torch.Size([1, 32, 512])
#        a
        attention = torch.matmul(enc_art, self._attn_wm).transpose(0, 1) # Here is not really attention, just a bank of enc hidden states to compute attention
#        print("attention ", attention.size(), attention)
#        attention  torch.Size([32, 25, 256])
#        print("sequence_mean(attention, art_lens, dim=1)", sequence_mean(attention, art_lens, dim=1).size(), sequence_mean(attention, art_lens, dim=1))
#        sequence_mean(attention, art_lens, dim=1) torch.Size([32, 256])
        
        init_attn_out = self._projection(torch.cat(
            [init_h[-1], sequence_mean(attention, art_lens, dim=1)], dim=1
        ))
#        print("init_attn_out ", init_attn_out.size(), init_attn_out)
#        init_attn_out  torch.Size([32, 128])
        
        return attention, (init_dec_states, init_attn_out), lp_postag

class AttentionalLSTMDecoderOperationNet(object):
    def __init__(self, embedding, embedding_postag, lstm, lstm_delete_decoder, attn_w, projection, projection_postag,
                 projection_delete_decoder_mask, projection_delete_decoder_postag, final_projection,
                 attn_del_out, coverage, W_c, cov_loss_wt):
        super().__init__()
        self._embedding = embedding
        self._embedding_postag = embedding_postag
        self._lstm = lstm
        self._lstm_delete_decoder = lstm_delete_decoder
        self._attn_w = attn_w
        self._projection = projection
        self._projection_postag = projection_postag
        self._projection_delete_decoder_mask = projection_delete_decoder_mask
        self._projection_delete_decoder_postag = projection_delete_decoder_postag
        self._final_projection = final_projection
        self._attn_del_out = attn_del_out
        self.is_coverage = coverage
        self.W_c = W_c
        self.cov_loss_wt = cov_loss_wt

    def __call__(self, attention, init_states, article, target, coverage):
        ''' Running in Abstractor (Abstractor Flow 2)'''
        
        # First pass: Decoder Network ----------------------
#        print("article ", article.size(), article)
#        print("target ", target.size(), target)
        max_len = article.size(1)
        states = init_states
        logit_source_binarys = []
        logit_source_postags = []
        for i in range(max_len): # Decoder: at training time, we go to max_len of target (loop), but then we will mask out decoder padding loss (computation). At test time, we also go to max_len default parameter (loop), then when we convert id2words, we stop when when we see EOS (display). On encoder: we go to enc length
            tok = article[:, i:i+1]
#            print("i ", i, " max_len ", max_len, " tok ", tok)
            logit, states, score, logit_postag, next_coverage = self._step_delete_decoder(tok, states, attention, coverage) # Abstractor Flow 3. Compute hidden state, context vector, copy, coverage at every time step
            logit_source_binarys.append(logit)
            logit_source_postags.append(logit_postag)
        logit_source_binary = torch.stack(logit_source_binarys, dim=1)        
        logit_source_postag = torch.stack(logit_source_postags, dim=1)   
        
        # Only keep prob of logit_source_binary_keep to compute attention
#        print("logit_source_binary ", logit_source_binary.size(), logit_source_binary)
#        a
#        logit_source_binary  torch.Size([32, 58, 2])
#        (logit_source_binary, None) = logit_source_binary
        prob_source_binary_keep = [[word[1] for word in sent] for sent in torch.exp(logit_source_binary)]
        prob_source_binary_keep = torch.Tensor(prob_source_binary_keep).to(logit_source_binary.device)
#        logit_source_binary_keep  torch.Size([32, 58])
#        prob_source_binary = torch.exp(logit_source_binary)
        
#        prob_source_binary_keep = torch.rand(article.size(0), article.size(1)).to(init_states[1].device)
#        prob_source_binary_keep = torch.ones(article.size(0), article.size(1)).to(init_states[1].device)
#        print("prob_source_binary_keep ", prob_source_binary_keep.size(), prob_source_binary_keep)
#        print("prob_source_binary ", torch.exp(logit_source_binary).size(), torch.exp(logit_source_binary))
        
        
        # Second pass: normal decoder ----------------------
        attention_tmp, attn_mask, extend_src, extend_vsize = attention
        attention = (attention_tmp, attn_mask, prob_source_binary_keep, extend_src, extend_vsize)
        
        max_len = target.size(1)
        states_ground_truth = init_states
        states_sampling = init_states
        states_greedy = init_states
        logits_ground_truth = [] # logit ml
        logits_greedy = [] # logit greedy
        logits_sampling = [] # logit rl sampling
        sampling_tokens = [] # rl sampling tokens
        greedy_tokens = []   # greedy token prediction
        logit_target_postags = []
        copy_probs = []
        coverage_loss_seq = []
        attn = []        
        
        for i in range(max_len): # Decoder: at training time, we still go to max_len (loop), but then we will mask out decoder padding loss (computation). At test time, we also go to max_len (loop), then when we convert id2words, we stop when when we see EOS (display). On encoder: we go to enc length
            tok = target[:, i:i+1]
#            print("i ", i, " max_len ", max_len, " tok ", tok)
            logit_ground_truth, _, states_ground_truth, score_ground_truth, logit_postag, copy_prob, next_coverage = self._step(tok, states_ground_truth, attention, coverage, "ml-prediction") # Abstractor Flow 3. Compute hidden state, context vector, copy, coverage at every time step
            
            # 2nd forward pass: RL sampling (sampling from mutilnomial distribution of logit, logit conditioned on sampling tokens)
            if i==0:
                tok = target[:, 0]           # SOS token
            else:
                tok = sampling_tokens[-1]
                # Resolve the case of rl-sampling & greedy-prediction:
                # If words from source is selected (means that index > vocab fixed embedding size), we transform this index into <unk> (index = 1) index to avoid bugging the system. Logit & token from source of the previous step is still kept to compute NLL & rouge w.r.t target tokens
                tok = tok.masked_fill_(tok >= self._embedding.num_embeddings, UNK) # fill index > vocab fixed embedding size with <unk> index 1
                # We can also rescale logit_extended to logit_vocab in the previous step, but then, there's a discrepancy between:
                # - logit_vocab & target word to compute NLL
                # - logit_vocab & token_extended to compute ROUGE                
            logit_sampling, sampling_token, states_sampling, score_sampling, logit_postag1, copy_prob, next_coverage = self._step(tok, states_sampling, attention, coverage, "rl-sampling")
			
            # 3rd forward pass: RL self-critic baseline - greedy argmax selection (just take argmax of logit)
            if i==0:
                tok = target[:, 0]			# SOS token
            else:
                tok = greedy_tokens[-1]
                tok = tok.masked_fill_(tok >= self._embedding.num_embeddings, UNK)  # fill index > vocab fixed embedding size with <unk> index 1
            logit_greedy, greedy_token, states_greedy, score_greedy, logit_postag1, copy_prob, next_coverage = self._step(tok, states_greedy, attention, coverage, "greedy-prediction")
		            
            # Coverage step 3. Add coverage loss into NLL loss
            if self.is_coverage:
                # score ~ attn_dist
                # good sign (+/-) in logit
                step_coverage_loss = torch.sum(torch.min(score, coverage), 1) 
                # attn_dist, coverage: B x source_len. torchmin -> smaller value of each B x source_len. torch.sum(dim=1) -> sum all attn_dist min of that sentence <= 1
#                print("logit size", logit.size())
#                print("step_coverage_loss size", step_coverage_loss.size())
                coverage_loss_seq.append(self.cov_loss_wt * step_coverage_loss)
                coverage = next_coverage
            
            logits_ground_truth.append(logit_ground_truth)
            logits_greedy.append(logit_greedy)
            logits_sampling.append(logit_sampling)
            sampling_tokens.append(sampling_token) # list of 32 1_token list (tok list at each step)
            greedy_tokens.append(greedy_token) # list of 32 1_token list  (tok list at each step)
            attn.append(score_greedy) # attn is only used at test time to replace UNK words by highest attn prob on source words (=> at test time, we can not use attn_ground_truth or attn_sampling)
            logit_target_postags.append(logit_postag)
            copy_probs.append(copy_prob)
            
        logit_ground_truth = torch.stack(logits_ground_truth, dim=1)
        logit_greedy = torch.stack(logits_greedy, dim=1)
        logit_sampling = torch.stack(logits_sampling, dim=1)
        sampling_token = torch.stack(sampling_tokens, dim=1).view(target.size()[0], -1) # torch.stack: convert python list to tensor array but it's still in 3d with tok at each timestep as a column list. view: reshape it into 2d array
        greedy_token = torch.stack(greedy_tokens, dim=1).view(target.size()[0], -1)
        logit_target_postag = torch.stack(logit_target_postags, dim=1)
        copy_prob = torch.stack(copy_probs, dim=1)
        if coverage_loss_seq:
            coverage_loss = torch.stack(coverage_loss_seq, dim=1)
        else:
            coverage_loss = None
#        print("logit ", logit.size())
#        print("copy_prob ", copy_prob.size(), copy_prob.squeeze()[:1,:])
#        logit  torch.Size([32, 7, 30009]) # 7: number of words on target
#        tensor([[[-11.0992, -11.5722, -11.2208,  ..., -11.0992, -11.0992, -11.0992],
#                 [-11.0594, -10.7012, -11.5615,  ..., -11.0594, -11.0594, -11.0594],
#        copy_prob  torch.Size([32, 7, 1]) # 7: number of words on target
#        a
        
        return (logit_source_binary, coverage_loss), (logit_source_postag, coverage_loss), \
                (logit_ground_truth, coverage_loss), (logit_sampling, sampling_token, logit_greedy, greedy_token, attn), \
                (logit_target_postag, coverage_loss), (copy_prob, coverage_loss)
#        return (logit_source_binary, None), (None, None)
#        return (None, coverage_loss), (logit, coverage_loss)


    def decode_step(self, tok, states, attention, coverage): # Coverage Full RL step 2.
        ''' Running in Full RL Abstractor (step 5)'''
        
        logit, greedy_token, states, score, logit_postag, copy_prob, coverage = self._step(tok, states, attention, coverage, "greedy-prediction") # Running full step 6.
        out = torch.max(logit, dim=1, keepdim=True)[1]
        return out, states, score, coverage
