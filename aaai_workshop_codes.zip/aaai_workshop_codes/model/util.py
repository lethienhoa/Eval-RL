import math
from scipy import stats

import torch
from torch.nn import functional as F


#################### general sequence helper #########################
def len_mask(lens, device):
    """ users are resposible for shaping
    Return: tensor_type [B, T]
    """
    max_len = max(lens)
    batch_size = len(lens)
    mask = torch.ByteTensor(batch_size, max_len).to(device)
    mask.fill_(0)
    for i, l in enumerate(lens):
        mask[i, :l].fill_(1)
    return mask

def sequence_mean(sequence, seq_lens, dim=1):
    if seq_lens:
        assert sequence.size(0) == len(seq_lens)   # batch_size
        sum_ = torch.sum(sequence, dim=dim, keepdim=False)
        mean = torch.stack([s/l for s, l in zip(sum_, seq_lens)], dim=0)
    else:
        mean = torch.mean(sequence, dim=dim, keepdim=False)
    return mean

def sequence_loss(logits, coverage_loss, targets, xent_fn=None, pad_idx=0):  # coverage_loss beside logit
    """ functional interface of SequenceLoss"""
#    if isinstance(logits, tuple):
#        logits, coverage_loss = logits
    assert logits.size()[:-1] == targets.size()
    
    mask = targets != pad_idx
#    print("targets ", targets.size(), targets)
    # 2D (batch_size x max_target_len) # 32 x 9
#    targets  tensor([
#    tensor([[   907,    153,    333,     83,      8,    405,     13,   2807,    3],
#            [    15,   4562,     11,   5979,    267,     14,   3655,   4981,    3],   
#            ...
#            [     1,      1,      3,      0,      0,      0,      0,      0,     0],
#            [   489,    138,      3,      0,      0,      0,      0,      0,     0]], device='cuda:0')            
    target = targets.masked_select(mask)
#    print("target ", len(target), target)
    # -> to 1D with masked_select (remove 0s and concatenate everything) : #elements here = 152 <= 32*9
#    target  tensor([   907,    153,    333,     83,      8,    405,     13,   2807,
#             3,     15,   4562,     11,   5979,    267,     14,   3655,
    
#    print("logits ", logits.size(), logits) # 3D: torch.Size([32, 9, 30023]) : batch x max_target_size x vocab_ext_size
#    logits  tensor([[[-11.0688, -10.9337, -11.0688,  ..., -11.0688, -11.0688,
#              -11.0688],
#             [-11.0719, -11.2166, -11.1860,  ..., -11.0719, -11.0719,
#              -11.0719],
#             [-11.0274, -10.7968, -11.1902,  ..., -11.0274, -11.0274,
#              -11.0274],
#             ...,
#             [-11.0847, -10.7677, -11.3221,  ..., -11.0847, -11.0847,
#              -11.0847],
#             [-11.0361, -10.8067, -11.4541,  ..., -11.0361, -11.0361,
#              -11.0361],
#             [-11.0287, -10.7846, -11.1554,  ..., -11.0287, -11.0287,
#              -11.0287]],
#    
#            [[-11.0613, -10.8438, -11.3821,  ..., -11.0613, -11.0613,
#              -11.0613],
#              ...    
    logit = logits.masked_select(
        mask.unsqueeze(2).expand_as(logits)
    ).contiguous().view(-1, logits.size(-1))
#    print("logit ", logit.size(), logit) # 2D: #elements here = 152 (<= 32*9) x 30023
#    logit  tensor([[-11.0688, -10.9337, -11.0688,  ..., -11.0688, -11.0688,
#             -11.0688],
#            [-11.0719, -11.2166, -11.1860,  ..., -11.0719, -11.0719,
#             -11.0719],
#             ...
    if xent_fn:
        loss = xent_fn(logit, target)
    else:
        loss = F.cross_entropy(logit, target)
#    print("loss size", loss.size())
    
    # Coverage step 4. Mask coverage loss on decoder
    if coverage_loss is not None:
        coverage_loss = coverage_loss.masked_select(mask)
        coverage_loss = coverage_loss.view(-1)
    #    print("coverage_loss size", coverage_loss.size())
        loss += coverage_loss
    
    assert (not math.isnan(loss.mean().item())
            and not math.isinf(loss.mean().item()))
    return loss

def sequence_loss_operation_net(logits, coverage_loss, targets, task="normal", xent_fn=None, pad_idx=0):  # coverage_loss beside logit
    """ functional interface of SequenceLoss"""
#    print(task)
#    print("targets.size() ", targets.size())
#    print("logits.size() ", logits.size())
#    for i in range(targets.size(0)):
#        print("targets ", i, ": ", targets[i]) # [32, 5]
#    print("logits ", logits.size(), logits.size()[:-1], logits) # [32, 5, 32003], [32, 5]
#    try:
#    assert logits.size()[:-1] == targets.size()
#    except:
    try:
        assert logits.size()[:-1] == targets.size()
#        if logits.size()[:-1] != targets.size():
#            for i in range(targets.size(0)):
#                print("targets ", i, ": ", targets[i]) # [32, 5]
#            print("logits ", logits) # [32, 5, 32003], [32, 5]     
#            print("targets.size() ", targets.size())
#            print("logits.size() ", logits.size(), logits.size()[:-1])
#            targets  
#            tensor([[ 4,  4,  4,  ...,  0,  0,  0],
#                    [ 4,  4,  4,  ...,  0,  0,  0],
#                    [ 5,  5,  4,  ...,  0,  0,  0],
#                    ...,
#                    [ 4,  5,  4,  ...,  0,  0,  0],
#                    [ 4,  4,  4,  ...,  4,  4,  4],
#                    [ 4,  5,  5,  ...,  0,  0,  0]], device='cuda:0')
#            logits  
#            tensor([[[-0.3771, -1.1579],
#                     [-0.0316, -3.4696],
#                     [-0.0048, -5.3437],
#                     ...,
#                     [-0.1756, -1.8258],
#                     [-0.1779, -1.8140],
#                     [-0.1801, -1.8028]],
#            targets.size()  torch.Size([32, 129])
#            logits.size()  torch.Size([32, 100, 2]) torch.Size([32, 100])
#            a
    except AssertionError as error:
#        for i in range(targets.size(0)):
#            print("targets ", i, ": ", targets[i]) # [32, 5]
#        print("logits ", logits) # [32, 5, 32003], [32, 5]     
        print("targets.size() ", targets.size())
        print("logits.size() ", logits.size(), logits.size()[:-1])
        a        
    
    mask = targets != pad_idx
#    print("targets ", targets.size(), targets)
    # 2D (batch_size x max_target_len) # 32 x 9
#    targets  tensor([
#    tensor([[   907,    153,    333,     83,      8,    405,     13,   2807,    3],
#            [    15,   4562,     11,   5979,    267,     14,   3655,   4981,    3],   
#            ...
#            [     1,      1,      3,      0,      0,      0,      0,      0,     0],
#            [   489,    138,      3,      0,      0,      0,      0,      0,     0]], device='cuda:0')       
    # mask gold target     
    target = targets.masked_select(mask)
#    print("target ", len(target), target)
    
    # Reconvert source_binary_gold from 4->0, 5->1 after masking. 
    # Coding NN: 
    # not just take care of dimension but its contents (transpose vs. view: rows & columns are well transposes like we wish ? - batch_first)
    # torch.div, torch.mul, torch.sum on rows, element that we want ? 
    # torch.squeeze or torch.unsqueeze to do other operations. 
    # Be careful about padding loss on enc & dec
    # Be careful: sigmoid and softmax are not the same on binary 2 classes ! right dimension to apply on ?
    # Variable(var.data, requires_grad=True).to(var.device) or var.detach().requires_grad_(): true way to copy value & detach grad history. Wrong: var.clone(): copy data & link grad history
    # convert from python list to tensor list: torch.stack(var_list) | not torch.cat(var_list) !
    
    # Other coding things:
    # Right input & output dim (2D or 3D, words or char level,...)
    # python list, numpy list, tensor list
    # convert all ops computations to tensor and put it on cuda !!!
    # declare networks architectures, parameters obj & its function vs. independent function, then pass data into these objects, inheritance, priority
    # multiprocess batch input
    
    if task == "delete_encoder" or task == "copy_prob":
        target[target==4] = 0 # 0
        target[target==5] = 1
#        print("target ", len(target), target)
#    a
    
    # -> to 1D with masked_select (remove 0s and concatenate everything) : #elements here = 152 <= 32*9
    # normal decoder
#    logit  torch.Size([288, 30021]) tensor([[-11.1200, -11.5681, -10.7466,  ..., -11.1200, -11.1200,
#             -11.1200],
#            [-11.0194, -11.5613, -10.7580,  ..., -11.0194, -11.0194,
#             -11.0194],
#            [-11.0626, -10.9662, -11.0061,  ..., -11.0626, -11.0626,
#             -11.0626],
#            ...,
#            [-11.0111, -11.1049, -10.7546,  ..., -11.0111, -11.0111,
#             -11.0111],
#            [-11.0206, -11.4945, -10.8689,  ..., -11.0206, -11.0206,
#             -11.0206],
#            [-10.9872, -11.8207, -11.0558,  ..., -10.9872, -10.9872,
#             -10.9872]], device='cuda:0')
#    target  torch.Size([288]) tensor([ 15010,   2382,    292,    146,    904,    450,      9,    877,
#                 3,    203,  16901,     87,      7,  29251,     10,     89,
#              5762,      3,   2399,  17656,  11008,     29,   1225,     11,
    # delete encoder 
#    logit  torch.Size([944, 2]) tensor([[-0.6911, -0.6952],
#            [-0.6976, -0.6887],
#            [-0.6928, -0.6935],
#            ...,
#            [-0.6890, -0.6973],
#            [-0.6887, -0.6976],
#            [-0.6855, -0.7009]], device='cuda:0')
#    target  torch.Size([944]) tensor([ 0,  0,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1,  1,
#             0,  0,  0,  0,  0,  0,  0,  0,  1,  0,  0,  0,  0,  0,
#             0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    # normal decoder has less #tokens but its #classes is much higher (30k vs. 2) than delete encoder. The probability of a lot of unrelated tokens is very small (-> high logit) -> on average, it has higher loss than delete encoder loss (where logit of prob 0.5 is more or less the same in 2 classes)
#    loss1  tensor(0.6913, device='cuda:0')
#    loss2  tensor(7.4810, device='cuda:0')    

    # mask logit
    logit = logits.masked_select(
        mask.unsqueeze(2).expand_as(logits)
    ).contiguous().view(-1, logits.size(-1))
#    print("target ", target.size(), target)
#    print("number 0: ", torch.sum(target==0))
#    print("number 1: ", torch.sum(target==1))
#    print(stats.describe(target.cpu().detach().numpy()))
#    print("logit ", logit.size(), logit) # 2D: #elements here = 152 (<= 32*9) x 30023
#    print(stats.describe(logit.cpu().detach().numpy()))
#    a
#    logit  tensor([[-11.0688, -10.9337, -11.0688,  ..., -11.0688, -11.0688,
#             -11.0688],
#            [-11.0719, -11.2166, -11.1860,  ..., -11.0719, -11.0719,
#             -11.0719],
#             ...
#    print("target ", target.size(), target)
    if task == "delete_encoder" or task == "normal" or task == "postag": # automatic normal cross-ent: logit: [152, 30023] or [152, 2]. true value: [152]
        if xent_fn:
            loss = xent_fn(logit, target)
        else:
            loss = F.cross_entropy(logit, target)
#        print("loss size", loss.size(), loss)
#        loss size torch.Size([309]) tensor([  4.6517,  10.9971,... 11.0097,   3.7440,  10.8802], device='cuda:0')
    elif task == "copy_prob": # manual cross-entropy for binary classification: COPY (must transform to copy & 1-copy to logit attribute to the right value 1 or 0): [152]. true value: [152]
        loss = []
        for i in range(len(target)): # TODO: optimize speed
            if target[i] == 1:
                loss.append(-torch.log(logit[i])) # logit here is just copy probability
            elif target[i] == 0:
                loss.append(-torch.log(1-logit[i]))
            # elif target[i] == 3: <EOS>: don't do anything, we must remove <EOS> col in the end of copy_prob (because we don't have class of <EOS> for it. P_t(w) already takes care of this) 
        loss = torch.cat(loss).to(logits.device) # torch.cat to concatenate to 1D, torch.stack to 2D !
#        print("loss size", loss.size(), loss)
#        a
#    print("loss size", loss.size())
    
    # Coverage step 4. Mask coverage loss on decoder
    if coverage_loss is not None:
        coverage_loss = coverage_loss.masked_select(mask)
        coverage_loss = coverage_loss.view(-1)
    #    print("coverage_loss size", coverage_loss.size())
        loss += coverage_loss
    
    assert (not math.isnan(loss.mean().item())
            and not math.isinf(loss.mean().item()))
    return loss


#################### LSTM helper #########################

def reorder_sequence(sequence_emb, order, batch_first=False):
    """
    sequence_emb: [T, B, D] if not batch_first
    order: list of sequence length
    """
    batch_dim = 0 if batch_first else 1
    assert len(order) == sequence_emb.size()[batch_dim]

    order = torch.LongTensor(order).to(sequence_emb.device)
    sorted_ = sequence_emb.index_select(index=order, dim=batch_dim)

    return sorted_

def reorder_lstm_states(lstm_states, order):
    """
    lstm_states: (H, C) of tensor [layer, batch, hidden]
    order: list of sequence length
    """
    assert isinstance(lstm_states, tuple)
    assert len(lstm_states) == 2
    assert lstm_states[0].size() == lstm_states[1].size()
    assert len(order) == lstm_states[0].size()[1]

    order = torch.LongTensor(order).to(lstm_states[0].device)
    sorted_states = (lstm_states[0].index_select(index=order, dim=1),
                     lstm_states[1].index_select(index=order, dim=1))

    return sorted_states
