""" attention functions """
from torch.nn import functional as F
import torch


def dot_attention_score(key, query):
    """[B, Tk, D], [(Bs), B, Tq, D] -> [(Bs), B, Tq, Tk]"""
    return query.matmul(key.transpose(1, 2))

def prob_normalize(score, mask):
    """ [(...), T]
    user should handle mask shape"""
    score = score.masked_fill(mask == 0, -1e18)
    norm_score = F.softmax(score, dim=-1)
    return norm_score

def attention_aggregate(value, score):
    """[B, Tv, D], [(Bs), B, Tq, Tv] -> [(Bs), B, Tq, D]"""
    output = score.matmul(value)
    return output


def step_attention(query, key, value, mem_mask=None):
    """ query[(Bs), B, D], key[B, T, D], value[B, T, D]"""
    score = dot_attention_score(key, query.unsqueeze(-2))
    if mem_mask is None:
        norm_score = F.softmax(score, dim=-1)
    else:
        norm_score = prob_normalize(score, mem_mask)
    output = attention_aggregate(value, norm_score)
    return output.squeeze(-2), norm_score.squeeze(-2)

def mask_source_binary_keep(attention_score, prob_source_binary_keep):
#    print("attention_score ", attention_score.size(), attention_score)
#    print("logit_source_binary_keep ", logit_source_binary_keep.size(), logit_source_binary_keep)
    attention_score_mask = torch.mul(attention_score, prob_source_binary_keep)
#    print("attention_score_mask ", attention_score_mask.size(), attention_score_mask)
#    print("attention_score_mask.transpose(0, 1) ", attention_score_mask.transpose(0, 1).size(), attention_score_mask.transpose(0, 1))
#    print("torch.sum(attention_score_mask, dim=1) ", torch.sum(attention_score_mask, dim=1).size(), torch.sum(attention_score_mask, dim=1))
#    print("torch.sum(attention_score_mask, dim=1) ", torch.sum(attention_score_mask, dim=1).size(), torch.sum(attention_score_mask, dim=1))

#    attention_score_norm = torch.div(attention_score_mask.transpose(0, 1), torch.sum(attention_score_mask, dim=1)) # normalized by sum of attention_score_mask on each sentence, torch.div only works by rows, so we need to tranpose batch & attn_sent to divide by sum_attn_weights of each sentence
#    print("attention_score_norm ", attention_score_norm.size(), attention_score_norm)

#    attention_score_norm = attention_score_norm.transpose(0, 1) # then, return back to [32, 58] batch first
#    print("attention_score_norm ", attention_score_norm.size(), attention_score_norm)
#    return attention_score_norm
    return attention_score_mask

def step_attention_operation_net(query, key, value, prob_source_binary_keep, mem_mask=None):
    """ query[(Bs), B, D], key[B, T, D], value[B, T, D]"""
    # query is decoder_t state
    # key = value = attention banks of enc states
#    print("query ", query.size(), query)
#    query  torch.Size([32, 256])
#    print("key ", key.size(), key)
#    key  torch.Size([32, 58, 256])
#    print("logit_source_binary_keep ", logit_source_binary_keep.size(), logit_source_binary_keep)
#    logit_source_binary  torch.Size([32, 58])
#    print("mem_mask ", mem_mask.size(), mem_mask)
#    mem_mask  torch.Size([32, 1, 58]) 
#    tensor([[[ 1,  1,  1,  ...,  0,  0,  0]],
#    
#            [[ 1,  1,  1,  ...,  0,  0,  0]],
#    
#            [[ 1,  1,  1,  ...,  0,  0,  0]],
#    
#            ...,
#    
#            [[ 1,  1,  1,  ...,  0,  0,  0]],
#    
#            [[ 1,  1,  1,  ...,  0,  0,  0]],
#    
#            [[ 1,  1,  1,  ...,  0,  0,  0]]], dtype=torch.uint8, device='cuda:0')    
#    a
    score = dot_attention_score(key, query.unsqueeze(-2))
#    print("score ", score.size(), score)
    #    score  torch.Size([32, 1, 58])
    
    # Mask attention score by logit_source_binary_keep first, before masking by length & computing new context vector
    score_delete_encoder = mask_source_binary_keep(score.squeeze(), prob_source_binary_keep) # input: same size [32 batch, 58 words max in each sentence]
    score_delete_encoder = score_delete_encoder.unsqueeze(1) # return back to [32, 1, 58] for the next step
#    print("score_delete_encoder ", score_delete_encoder.size(), score_delete_encoder)
#    a

    if mem_mask is None:
        norm_score = F.softmax(score, dim=-1)
        norm_score_delete_encoder = F.softmax(score_delete_encoder, dim=-1)
    else:
        norm_score = prob_normalize(score, mem_mask)
        norm_score_delete_encoder = prob_normalize(score_delete_encoder, mem_mask)
#    print("norm_score ", norm_score.size(), norm_score)
#    print("norm_score_delete_encoder ", norm_score_delete_encoder.size(), norm_score_delete_encoder)
#    a
#    norm_score  torch.Size([32, 1, 25])
    output = attention_aggregate(value, norm_score)
#    print("output ", output.size(), output)
#    output  torch.Size([32, 1, 256])
#    print("norm_score.squeeze(-2) ", norm_score.squeeze(-2).size(), norm_score.squeeze(-2))
#    print("output.squeeze(-2) ", output.squeeze(-2).size(), output.squeeze(-2))
#    a
    return output.squeeze(-2), norm_score_delete_encoder.squeeze(-2) # new context_vector [32, 256] & attention_weights for each sentence [32, 25]
#    return output.squeeze(-2), norm_score.squeeze(-2)
    # context vector (use regular attention weights), only change score of attention weight (masked by delete enc) to enhance keep words probability from source




#def mask_source_binary_keep(attention_score, prob_source_binary_keep):
#    attention_score_mask = torch.mul(attention_score, prob_source_binary_keep)
##    print("attention_score_mask ", attention_score_mask.size(), attention_score_mask)
#    attention_score_norm = torch.div(attention_score_mask.transpose(0, 1), torch.sum(attention_score_mask, dim=1)) # normalized by sum of attention_score_mask on each sentence, torch.div only works by rows, so we need to tranpose batch & attn_sent to divide by sum_attn_weights of each sentence
##    print("attention_score_norm ", attention_score_norm.size(), attention_score_norm)
#    attention_score_norm = attention_score_norm.transpose(0, 1) # then, return back to [32, 58] batch first
##    print("attention_score_norm ", attention_score_norm.size(), attention_score_norm)
##    A
#    return attention_score_mask
#    
#def step_attention_operation_net(query, key, value, prob_source_binary_keep, mem_mask=None):
#    """ query[(Bs), B, D], key[B, T, D], value[B, T, D]"""
#
#    score = dot_attention_score(key, query.unsqueeze(-2))
#
#    if mem_mask is None:
#        norm_score = F.softmax(score, dim=-1)
#    else:
#        norm_score = prob_normalize(score, mem_mask)
#
#    output = attention_aggregate(value, norm_score)
##    print("norm_score ", norm_score.size(), norm_score)
##    print("prob_source_binary_keep ", prob_source_binary_keep.size(), prob_source_binary_keep)
#    norm_score_delete_encoder = mask_source_binary_keep(norm_score.squeeze(), prob_source_binary_keep) # input: same size [32 batch, 58 words max in each sentence]
#    norm_score_delete_encoder = norm_score_delete_encoder.unsqueeze(1) 
#
#    return output.squeeze(-2), norm_score_delete_encoder.squeeze(-2) # new context_vector [32, 256] & attention_weights for each sentence [32, 25]
