#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri May 17 16:11:14 2019

@author: yannickpar
"""


gold_abstract = open("/home/yannickpar/fast_abs_rl/analyse_results/statspos_gold_abstract",'r').readlines()
gen_file = open("/home/yannickpar/fast_abs_rl/analyse_results/statspos_baseline_gen",'r').readlines()

stats_dict = {}
stats_dict['4'] = [0, 0.]
stats_dict['6'] = [0, 0.]
stats_dict['8'] = [0, 0.]
stats_dict['10'] = [0, 0.]
stats_dict['12'] = [0, 0.]
stats_dict['12+'] = [0, 0.]

for j in range(1951):
    gold_abstract[j] = gold_abstract[j].replace("\n","")
    gen_file[j] = gen_file[j].replace("\n","")
    
    len_gen_j = len(gen_file[j].split(" "))
    
    rep_gen_j = len(gen_file[j].split(" ")) - len(set(gen_file[j].split(" ")))
    rep_abs_j = len(gold_abstract[j].split(" ")) - len(set(gold_abstract[j].split(" ")))
    rep_rate_j = (1+rep_gen_j) / float(1+rep_abs_j)
    
    if len_gen_j <= 4:
        stats_dict['4'][0] += 1
        stats_dict['4'][1] += rep_rate_j           
    elif len_gen_j <= 6:
        stats_dict['6'][0] += 1
        stats_dict['6'][1] += rep_rate_j            
    elif len_gen_j <= 8:
        stats_dict['8'][0] += 1
        stats_dict['8'][1] += rep_rate_j     
    elif len_gen_j <= 10:
        stats_dict['10'][0] += 1
        stats_dict['10'][1] += rep_rate_j            
    elif len_gen_j <= 12:
        stats_dict['12'][0] += 1
        stats_dict['12'][1] += rep_rate_j    
    else:
        stats_dict['12+'][0] += 1
        stats_dict['12+'][1] += rep_rate_j           
        
sum_check = 0
for i in ['4', '6', '8', '10', '12', '12+']:
    sum_check += stats_dict[str(i)][0]
    print(stats_dict[i], stats_dict[i][1]/stats_dict[i][0])

print(sum_check)


#([312, 557.9484126984127], 1.7882961945461944)
#([648, 759.0750000000002], 1.1714120370370373)
#([633, 755.9666666666667], 1.1942601369141654)
#([245, 340.48333333333335], 1.3897278911564626)
#([62, 123.58333333333333], 1.993279569892473)
#([51, 623.0333333333333], 12.216339869281045)
#1951
