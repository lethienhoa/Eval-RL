""" train the abstractor"""
import argparse
import json
import os
from os.path import join, exists
import pickle as pkl
import re

from cytoolz import compose

from toolz.sandbox.core import unzip
from data.batcher_gen_postag import tokenize
import torch
from torch import optim
from torch.nn import functional as F
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader
from time import time

from model.copy_summ_hierar_posdeptag import CopySummOperationNet
#from model.copy_summ_no_dec import CopySummNoDec
#from model.copy_summ_cnn_enc import CopySummCNNEnc
from model.util import sequence_loss_operation_net
from training_hierar_posdeptag import get_basic_grad_fn, basic_validate
from training_hierar_posdeptag import BasicPipeline, BasicTrainer

from data.data import CnnDmDataset
from data.batcher_gen_postag import coll_fn_operation, prepro_fn_operation
from data.batcher_gen_postag import convert_batch_copy_operation, batchify_fn_copy_operation
from data.batcher_gen_postag import BucketedGenerater

from utils import PAD, UNK, START, END
from utils import make_vocab, make_embedding

# NOTE: bucket size too large may sacrifice randomness,
#       to low may increase # of PAD tokens
BUCKET_SIZE = 6400

try:
    DATA_DIR = os.environ['DATA']
except KeyError:
    print('please use environment variable to specify data directories')

class MatchDataset(CnnDmDataset):
    """ single article sentence -> single abstract sentence
    (dataset created by greedily matching ROUGE)
    """
    def __init__(self, split):
        super().__init__(split, DATA_DIR)

    def __getitem__(self, i):
        js_data = super().__getitem__(i)
        original_document, source_binary, source_postag, source_dependencytag, source_ner, \
            abstract, abstract_binary, abstract_postag = (
            js_data['original_document'], js_data['original_document'], js_data['source_postag'], js_data['source_dependencytag'], js_data['source_ner'],
            js_data['abstract'], js_data['abstract'], js_data['abstract_postag'])
        return [original_document], [source_binary], [source_postag], [source_dependencytag], [source_ner], \
                [abstract], [abstract_binary], [abstract_postag] # list 1 element


def configure_net(vocab_size, postag_size, deptag_size, nertag_size, emb_dim,
                  n_hidden, bidirectional, n_layer, dropout, coverage):
    net_args = {}
    net_args['vocab_size']    = vocab_size
    net_args['postag_size']    = postag_size
    net_args['deptag_size']    = deptag_size
    net_args['nertag_size']    = nertag_size
    net_args['emb_dim']       = emb_dim
    net_args['n_hidden']      = n_hidden
    net_args['bidirectional'] = bidirectional
    net_args['n_layer']       = n_layer
    net_args['dropout']       = dropout
    net_args['coverage']      = coverage

    net = CopySummOperationNet(**net_args)
    
    return net, net_args


def configure_training(opt, lr, clip_grad, lr_decay, batch_size):
    """ supports Adam optimizer only"""
    assert opt in ['adam']
    opt_kwargs = {}
    opt_kwargs['lr'] = lr

    train_params = {}
    train_params['optimizer']      = (opt, opt_kwargs)
    train_params['clip_grad_norm'] = clip_grad
    train_params['batch_size']     = batch_size
    train_params['lr_decay']       = lr_decay

    nll = lambda logit, target: F.nll_loss(logit, target, reduce=False)
    def criterion(logits, coverage, targets, task="normal"): # coverage_loss beside logit
        return sequence_loss_operation_net(logits, coverage, targets, task, nll, pad_idx=PAD)  # coverage_loss beside logit

    return criterion, train_params

def build_batchers(word2id, postag2id, deptag2id, nertag2id, cuda, debug, batch_size):
    def coll(batch):
        art_batch, source_binary_batch, source_postag_batch, source_dependencytag_batch, source_ner_batch, \
            abstract_batch, abstract_binary_batch, abstract_postag_batch = unzip(batch)
        art_sents = list(filter(bool, map(tokenize(None), art_batch)))
        source_binary_sents = None # don't have value to tokenize
        source_postag_sents = list(filter(bool, map(tokenize(None), source_postag_batch)))
        source_dependencytag_sents = list(filter(bool, map(tokenize(None), source_dependencytag_batch)))
        source_ner_sents = list(filter(bool, map(tokenize(None), source_ner_batch)))
        abstract_sents = list(filter(bool, map(tokenize(None), abstract_batch)))
        abstract_binary_sents = None # don't have value to tokenize
        abstract_postag_sents = list(filter(bool, map(tokenize(None), abstract_postag_batch)))
        return art_sents, source_binary_sents, source_postag_sents, source_dependencytag_sents, source_ner_sents, \
                abstract_sents, abstract_binary_sents, abstract_postag_sents
    
    prepro = prepro_fn_operation(args.max_art, args.max_abs)
    def sort_key(sample):
        src, src_binary, src_postag, src_deptag, src_ner, target, target_binary, target_postag = sample
        return (len(target), len(target_binary), len(target_postag), len(src), len(src_binary), len(src_postag), len(src_deptag), len(src_ner))
    batchify = compose(
        batchify_fn_copy_operation(PAD, START, END, cuda=cuda),
        convert_batch_copy_operation(UNK, word2id, postag2id, deptag2id, nertag2id)
    )

    train_loader = DataLoader(
        MatchDataset('train_small_ex'), batch_size=BUCKET_SIZE, # 1M536k_train_del_para
        shuffle=not debug,
        num_workers=4 if cuda and not debug else 0,
        collate_fn=coll_fn_operation
    )
    train_batcher = BucketedGenerater(train_loader, prepro, sort_key, batchify,
                                      single_run=False, fork=not debug)

    val_loader = DataLoader(
        MatchDataset('val'), batch_size=BUCKET_SIZE,
        shuffle=False, num_workers=4 if cuda and not debug else 0,
        collate_fn=coll_fn_operation
    )
    val_batcher = BucketedGenerater(val_loader, prepro, sort_key, batchify,
                                    single_run=True, fork=not debug)
    
    test_loader = DataLoader(
        MatchDataset('test'), batch_size=batch_size,
        shuffle=False, num_workers=4,
        collate_fn=coll
    )
#    test_batcher = BucketedGenerater(test_loader, prepro, sort_key, batchify,
#                                    single_run=True, fork=not debug)
    
    return train_batcher, val_batcher, test_loader

def load_best_ckpt(model_dir, reverse=False):
    """ reverse=False->loss, reverse=True->reward/score"""
    ckpts = os.listdir(join(model_dir, 'ckpt'))
    ckpt_matcher = re.compile('^ckpt-.*-[0-9]*')
    ckpts = sorted([c for c in ckpts if ckpt_matcher.match(c)],
                   key=lambda c: float(c.split('-')[1]), reverse=reverse)
    print('loading checkpoint {}...'.format(ckpts[0]))
    ckpt = torch.load(
        join(model_dir, 'ckpt/{}'.format(ckpts[0]))
    )['state_dict']
    return ckpt

def make_vocab_from_file(vocab_file_name):
    filelines = open(join(DATA_DIR, vocab_file_name), 'r').readlines()
    
    word2id = {}
    word2id['<pad>'] = 0
    word2id['<unk>'] = 1
    word2id['<start>'] = 2
    word2id['<end>'] = 3
    cnt = 4 # start from 4
    for i in range(len(filelines)):
        word2id[filelines[i].replace("\n","").lower()] = cnt # i
        cnt += 1
    return word2id

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def main(args):
    # create data batcher, vocabulary
    # batcher
    with open(join(DATA_DIR, 'vocab_cnt.pkl'), 'rb') as f:
        wc = pkl.load(f)
    word2id = make_vocab(wc, args.vsize)
    
    # postag vocab
    postag2id = make_vocab_from_file('vocab_postag.txt') 
    deptag2id = make_vocab_from_file('vocab_deptag.txt') 
    nertag2id = make_vocab_from_file('vocab_nertag.txt')     
#    print(postag2id)
#    a
    
    train_batcher, val_batcher, test_batcher = build_batchers(word2id, postag2id, deptag2id, nertag2id,
                                                args.cuda, args.debug, args.batch)

    # make net
    net, net_args = configure_net(len(word2id), len(postag2id), len(deptag2id), len(nertag2id), args.emb_dim,
                                  args.n_hidden, args.bi, args.n_layer, args.dropout, args.coverage)

    # load pretrained Abstractor
    if args.pretrained_path is not None:
        abs_ckpt = load_best_ckpt(args.pretrained_path)
        net.load_state_dict(abs_ckpt)    
    
    if args.w2v:
        # NOTE: the pretrained embedding having the same dimension
        #       as args.emb_dim should already be trained
        embedding, _ = make_embedding(
            {i: w for w, i in word2id.items()}, args.w2v)
        net.set_embedding(embedding)

    # configure training setting
    criterion, train_params = configure_training(
        'adam', args.lr, args.clip, args.decay, args.batch
    )

    # save experiment setting
    if not exists(args.path):
        os.makedirs(args.path)
    with open(join(args.path, 'vocab.pkl'), 'wb') as f:
        pkl.dump(word2id, f, pkl.HIGHEST_PROTOCOL)
    meta = {}
    meta['net']           = 'base_abstractor'
    meta['net_args']      = net_args
    meta['traing_params'] = train_params
    with open(join(args.path, 'meta.json'), 'w') as f:
        json.dump(meta, f, indent=4)

    # prepare trainer
    val_fn = basic_validate(net, criterion) # same total loss or alternate loss (with 2 different val_fn ?)
    grad_fn = get_basic_grad_fn(net, args.clip)
    optimizer = optim.Adam(net.parameters(), **train_params['optimizer'][1])
    scheduler = ReduceLROnPlateau(optimizer, 'min', verbose=True,
                                  factor=args.decay, min_lr=0,
                                  patience=args.lr_p)

    if args.cuda:
        net = net.cuda()
        
    count = count_parameters(net)
    print("Number of parameters: ", count)
    print("Start time: ", time())
        
    pipeline = BasicPipeline(meta['net'], net,
                             train_batcher, val_batcher, test_batcher, args.batch, val_fn,
                             criterion, optimizer, word2id, postag2id, deptag2id, nertag2id, grad_fn,)
    trainer = BasicTrainer(pipeline, args.path,
                           args.ckpt_freq, args.patience, scheduler)

    print('start training with the following hyper-parameters:')
    print(meta)
    trainer.train()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='training of the abstractor (ML)'
    )
    parser.add_argument('--path', required=True, help='root of the model')
    parser.add_argument('--pretrained_path', type=str, action='store', default=None,
                        help='pretrained abstractor directory')

    parser.add_argument('--vsize', type=int, action='store', default=30000,
                        help='vocabulary size')
    parser.add_argument('--emb_dim', type=int, action='store', default=128,
                        help='the dimension of word embedding')
    parser.add_argument('--w2v', action='store',
                        help='use pretrained word2vec embedding')
    parser.add_argument('--n_hidden', type=int, action='store', default=256,
                        help='the number of hidden units of LSTM')
    parser.add_argument('--n_layer', type=int, action='store', default=1,
                        help='the number of layers of LSTM')
    parser.add_argument('--no-bi', action='store_true',
                        help='disable bidirectional LSTM encoder')
    parser.add_argument('--dropout', type=float, action='store', default=0.0,
                        help='dropout')    
    parser.add_argument('--coverage', type=bool, action='store', default=False,
                        help='coverage')        

    # length limit
    parser.add_argument('--max_art', type=int, action='store', default=100,
                        help='maximun words in a single article sentence')
    parser.add_argument('--max_abs', type=int, action='store', default=30,
                        help='maximun words in a single abstract sentence')
    # training options
    parser.add_argument('--lr', type=float, action='store', default=1e-3,
                        help='learning rate')
    parser.add_argument('--decay', type=float, action='store', default=0.5,
                        help='learning rate decay ratio')
    parser.add_argument('--lr_p', type=int, action='store', default=0,
                        help='patience for learning rate decay')
    parser.add_argument('--clip', type=float, action='store', default=2.0,
                        help='gradient clipping')
    parser.add_argument('--batch', type=int, action='store', default=32,
                        help='the training batch size')
    parser.add_argument(
        '--ckpt_freq', type=int, action='store', default=3000,
        help='number of update steps for checkpoint and validation'
    )
    parser.add_argument('--patience', type=int, action='store', default=5,
                        help='patience for early stopping')

    parser.add_argument('--debug', action='store_true',
                        help='run in debugging mode')
    parser.add_argument('--no-cuda', action='store_true',
                        help='disable GPU training')
    args = parser.parse_args()
    args.bi = not args.no_bi
    args.cuda = torch.cuda.is_available() and not args.no_cuda

    main(args)
