# -*- coding: utf-8 -*-
"""
Created on Mon Oct 22 20:23:39 2018

@author: hoa
"""
from __future__ import division
import shutil
#from shutil import copy2
import os.path
import json
import numpy as np
import os
from collections import Counter
import xml.etree.ElementTree as ET

from shutil import copyfile
from scipy import stats

from corenlpy import AnnotatedText as A # https://github.com/enewe101/corenlpy
import sys
reload(sys)
sys.setdefaultencoding('utf8')
from stanfordcorenlp import StanfordCoreNLP # https://github.com/Lynten/stanford-corenlp

port = 8000
print("port ", port)

class StanfordNLP:
    def __init__(self, host='http://localhost', port=port):
        self.nlp = StanfordCoreNLP(host, port=port,
                                   timeout=100000)  # , quiet=False, logging_level=logging.DEBUG)
        self.props = {
            'annotators': 'tokenize,ssplit,pos,lemma,ner,parse,depparse,openie',
            'pipelineLanguage': 'en',
            'outputFormat': 'xml',
        }

    def annotate(self, sentence):
        return self.nlp.annotate(sentence, properties=self.props)
        
sNLP = StanfordNLP()
      

      
dirr = "/home/hoa/fast_abs_rl/data_SDparsing/DependencyJSON/train/" # train_IEDP3a4bfull, val_ext2_IEDP_n_1_full_IEDPmix, val_ner_filtered3a_first
dirr_to1 = "/home/hoa/fast_abs_rl/data_SDparsing/JSONdata/cleaned_train/" # train_IEDP3a4bfull_small, val_IEDP_n_1_full_IEDPmix
if not os.path.exists(dirr_to1):
    os.mkdir(dirr_to1)
    
def constituencytag(textdata):
    # Constituency Parsing (contains POS tag)
    xml = sNLP.annotate(textdata)

    constituencytag = [] # contain postag as leaves
    root = ET.fromstring(xml)
    for node in root.findall('./document/sentences/sentence/parse'):
        constituencytag.append(node.text.replace("(", "").replace(")", "").strip())
        
    return " ".join(constituencytag) # emb4, contain postag as leaves [ROOT S NP NNP ...]


#for i in range(96000, 500000):                  1 day          done
#for i in range(400000, 500000):           #     1 day          done
#for i in range(500000, 1000000): # 1951         1 day          done
    
#for i in range(857600, 8586000): # 1951          1 day          done
#for i in range(858600, 860000): # 1951          1 day          done    
#for i in range(861600, 862600): # 1951          1 day          done        
#for i in range(862600, 863600): # 1951          1 day          done     
       
#for i in range(866700, 8677000): # 1951          1 day          done                
#for i in range(867700, 8687000): # 1951          1 day          done          
#for i in range(868700, 870000): # 1951          1 day          done          
#for i in range(872000, 873000): # 1951          1 day          done       
for i in range(874000, 875000): # 1951          1 day          done         
    
    
    #for i in range(900000, 1000000): # 1951     1 day          done
#for i in range(1000000, 1500000): # 1951        1 day          done
    #for i in range(1300000, 1500000): # 1951                   done
#for i in range(1500000, 2000000): # 1951        1 day          done
    #for i in range(1800000, 2000000): # 1951                   done  
#for i in range(2000000, 2500000): # 1951        1 day          done
    #for i in range(2300000, 2500000): # 1951                   done
#for i in range(2500000, 3000000): # 1951        1 day          done
    #for i in range(2800000, 3000000): # 1951                   done 
#for i in range(3000000, 3500000): # 1951        1 day          done
    #for i in range(3300000, 3500000): # 1951                   done
#for i in range(3500000, 3800000): # 1951        1 day          done
    if i % 100 == 0:
        print(i)
        
    with open(dirr + str(i) + '.json', 'r') as f:
        data = json.loads(f.read())   
        
    del data['article'] 
    del data['extracted'], data['score'], data['score_triple1'], data['score_triple2'], data['score_tripleL']
    del data['score_original_doc1'], data['score_original_doc2'], data['score_original_docL']

    data['abstract'] = data['abstract'][0]

    #
    annotated_text = A(sNLP.annotate(data['abstract'])) # get annotated format XML file to object
    sentences = annotated_text.sentences  
    ner = []
    postag = []
    dependencytag = []
    words = []
    for sentence in sentences: # ['tokens', 'entities', 'references', 'mentions', 'root', 'id']
        for word in sentence['tokens']:
            if word['ner']:
                ner.append(word['ner'])
            else:
                ner.append("None")
            if word['parents']:
                dependencytag.append(word['parents'][0][0]) # word['parents'] has only 1 element, first element word['parents'] has (relation, parent)
            else:
                dependencytag.append("None")
            postag.append(word['pos'])
            words.append(word['word'])
    data['abstract_postag'] = " ".join(postag)   
    data['abstract'] = " ".join(words)
    data['abstract_ner'] = " ".join(ner) # emb2 [STATE_OR_PROVINCE, ORGANIZATION,...] : disambiguation
    data['abstract_dependencytag'] = " ".join(dependencytag) # emb3 : [punct appos punct dep det dep case...]
    #
    annotated_text = A(sNLP.annotate(data['original_document'])) # get annotated format XML file to object
    sentences = annotated_text.sentences  
    ner = []
    postag = []
    dependencytag = []
    words = []
    for sentence in sentences: # ['tokens', 'entities', 'references', 'mentions', 'root', 'id']
        for word in sentence['tokens']:
            if word['ner']:
                ner.append(word['ner'])
            else:
                ner.append("None")
            if word['parents']:
                dependencytag.append(word['parents'][0][0]) # word['parents'] has only 1 element, first element word['parents'] has (relation, parent)
            else:
                dependencytag.append("None")
            postag.append(word['pos'])
            words.append(word['word'])
    data['source_postag'] = " ".join(postag)   
    data['original_document'] = " ".join(words)
    data['source_ner'] = " ".join(ner) # emb2 [STATE_OR_PROVINCE, ORGANIZATION,...] : disambiguation
    data['source_dependencytag'] = " ".join(dependencytag) # emb3 : [punct appos punct dep det dep case...]    
    
    #
    data['abstract_constituencytag'] = constituencytag(data['abstract']) 
    data['source_constituencytag'] = constituencytag(data['original_document'])     
    
    
    with open(dirr_to1 + str(i) + '.json', 'w') as g:
        json.dump(data, g, indent=4, sort_keys = True)    

#    print(data)        
#    a
