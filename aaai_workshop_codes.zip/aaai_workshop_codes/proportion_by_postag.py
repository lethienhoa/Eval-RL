#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri May 17 16:11:14 2019

@author: yannickpar
"""

file_name = "/home/hoa/fast_abs_rl/delete_paraphrase/analyse_results/statspos_gold_abstract"
print(file_name)
gen_file = open(file_name,'r').readlines()

stats_dict = {}
stats_dict['SYM'] = 0.
stats_dict['TO'] = 0.
stats_dict['IN'] = 0.
stats_dict['CD'] = 0.
stats_dict['DT'] = 0.
stats_dict['NN'] = 0.
stats_dict['VV'] = 0.
stats_dict['JJ'] = 0.
stats_dict['RB'] = 0.

def rep_by_postag(taglist, tagattr, gen):
    total_cnt = 0
    for tag in taglist:
        total_cnt += gen.count(tag)
    rep_gen_j = total_cnt / len(gen)
    stats_dict[tagattr] += rep_gen_j

for j in range(1951):
    gen_file[j] = gen_file[j].replace("\n","")
    
    rep_by_postag(['SYM', '.', '#', ':', ','], 'SYM', gen_file[j].split(" "))
    rep_by_postag(['TO'], 'TO', gen_file[j].split(" "))
    rep_by_postag(['IN'], 'IN', gen_file[j].split(" "))
    rep_by_postag(['CD'], 'CD', gen_file[j].split(" "))
    rep_by_postag(['DT'], 'DT', gen_file[j].split(" "))
    rep_by_postag(['NN', 'NNS', 'NNP', 'NNPS'], 'NN', gen_file[j].split(" "))
    rep_by_postag(['VB','VBD','VBG','VBN','VBP','VBZ'], 'VV', gen_file[j].split(" "))
    rep_by_postag(['JJ','JJR','JJS'], 'JJ', gen_file[j].split(" "))
    rep_by_postag(['RB','RBR','RBS'], 'RB', gen_file[j].split(" "))
        
total = 0
for key, element in stats_dict.items():
    total += element/1951
    print(key, element/1951)

print(total)


#([312, 557.9484126984127], 1.7882961945461944)
#([648, 759.0750000000002], 1.1714120370370373)
#([633, 755.9666666666667], 1.1942601369141654)
#([245, 340.48333333333335], 1.3897278911564626)
#([62, 123.58333333333333], 1.993279569892473)
#([51, 623.0333333333333], 12.216339869281045)
#1951
