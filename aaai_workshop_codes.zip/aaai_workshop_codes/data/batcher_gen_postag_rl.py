""" batching """
import random
from collections import defaultdict

from toolz.sandbox import unzip
from cytoolz import curry, concat, compose
from cytoolz import curried

import torch
import torch.multiprocessing as mp


# Batching functions
def coll_fn(data):
    source_lists, source_keep_lists, target_lists = unzip(data)
    # NOTE: independent filtering works because
    #       source and targets are matched properly by the Dataset
    sources = list(filter(bool, concat(source_lists)))
    source_keeps = list(filter(bool, concat(source_keep_lists)))
    targets = list(filter(bool, concat(target_lists)))
    assert all(sources) and all(targets)
    return sources, source_keeps, targets

def coll_fn_operation(data):
    source_lists, source_binary_lists, source_postag_lists, source_deptag_lists, source_ner_lists, \
        target_lists, target_binary_lists, target_postag_lists = unzip(data)
    # NOTE: independent filtering works because
    #       source and targets are matched properly by the Dataset
    sources = list(filter(bool, concat(source_lists)))
    source_binarys = list(filter(bool, concat(source_binary_lists)))
    source_postags = list(filter(bool, concat(source_postag_lists)))
    source_deptags = list(filter(bool, concat(source_deptag_lists)))
    source_nertags = list(filter(bool, concat(source_ner_lists)))
    targets = list(filter(bool, concat(target_lists)))
    target_binary = list(filter(bool, concat(target_binary_lists)))
    target_postags = list(filter(bool, concat(target_postag_lists)))
    assert all(sources) and all(targets)
    return sources, source_binarys, source_postags, source_deptags, source_nertags, targets, target_binary, target_postags

def coll_fn_extract(data):
    def is_good_data(d):
        """ make sure data is not empty"""
        source_sents, extracts = d
        return source_sents and extracts
    batch = list(filter(is_good_data, data))
    assert all(map(is_good_data, batch))
    return batch

@curry
def tokenize(max_len, texts):
    return [t.lower().split()[:max_len] for t in texts]

def conver2id(unk, word2id, words_list):
    word2id = defaultdict(lambda: unk, word2id)
    return [[word2id[w] for w in words] for words in words_list]

@curry
def prepro_fn(max_src_len, max_tgt_len, batch):
    sources, source_keeps, targets = batch
    sources = tokenize(max_src_len, sources)
    source_keeps = tokenize(max_src_len, source_keeps)
    targets = tokenize(max_tgt_len, targets)
    batch = list(zip(sources, source_keeps, targets))
    return batch

@curry
def prepro_fn_operation(max_src_len, max_tgt_len, batch): # 2000 examples
    sources, source_binary, source_postag, source_deptag, source_ner, targets, target_binary, target_postag = batch
    sources = tokenize(max_src_len, sources)
    source_binary = [sents[:max_src_len] for sents in source_binary] # source_binary is already a "tokenized" list
    source_postag = tokenize(max_src_len, source_postag)
    source_deptag = tokenize(max_src_len, source_deptag)
    source_ner = tokenize(max_src_len, source_ner)
    
    targets = tokenize(max_tgt_len, targets)
    target_binary = [sents[:max_tgt_len] for sents in target_binary] # target_binary is already a "tokenized" list
    target_postag = tokenize(max_tgt_len, target_postag)

#    print("\n source_binary ", len(source_binary), source_binary)
#    l = [len(item) for item in source_binary]
#    print(l)    
#    print("\n source_postag ", len(source_postag), source_postag)
#    l = [len(item) for item in source_postag]
#    print(l)     
#    print("\n targets ", len(targets), targets)
#    l = [len(item) for item in targets]
#    print(l)     
#    print("\n target_postag ", len(target_postag), target_postag)
#    l = [len(item) for item in target_postag]
#    print(l)     
#    a
    batch = list(zip(sources, source_binary, source_postag, source_deptag, source_ner, targets, target_binary, target_postag))
    return batch

@curry
def prepro_fn_extract(max_src_len, max_src_num, batch):
    def prepro_one(sample):
        source_sents, extracts = sample
        tokenized_sents = tokenize(max_src_len, source_sents)[:max_src_num]
        cleaned_extracts = list(filter(lambda e: e < len(tokenized_sents),
                                       extracts))
        return tokenized_sents, cleaned_extracts
    batch = list(map(prepro_one, batch))
    return batch

@curry
def convert_batch(unk, word2id, batch):
    sources, targets = unzip(batch)
    sources = conver2id(unk, word2id, sources)
    targets = conver2id(unk, word2id, targets)
    batch = list(zip(sources, targets))
    return batch

@curry
def convert_batch_copy(unk, word2id, batch):
    sources, source_keeps, targets = map(list, unzip(batch))
    ext_word2id = dict(word2id)
    for source in sources:
        for word in source:
            if word not in ext_word2id:
                ext_word2id[word] = len(ext_word2id)
    src_exts = conver2id(unk, ext_word2id, sources)
    sources = conver2id(unk, word2id, sources)
    
    src_keep_exts = conver2id(unk, ext_word2id, source_keeps)
    src_keeps = conver2id(unk, word2id, source_keeps)
    
    tar_ins = conver2id(unk, word2id, targets)
    targets = conver2id(unk, ext_word2id, targets)
    batch = list(zip(sources, src_exts, src_keeps, src_keep_exts, tar_ins, targets))
    return batch

@curry
def convert_batch_copy_operation(unk, word2id, postag2id, deptag2id, nertag2id, batch):
    sources, source_binarys, source_postags, source_deptags, source_ners, targets, target_binarys, target_postags = map(list, unzip(batch))
    ext_word2id = dict(word2id)
    sources_words = sources
    targets_words = targets    
    ext_word2id = dict(word2id)
    for source in sources:
        for word in source:
            if word not in ext_word2id:
                ext_word2id[word] = len(ext_word2id)
    ext_id2word = {i: w for w, i in ext_word2id.items()}
#    print("ext_id2word ", ext_id2word)
    src_exts = conver2id(unk, ext_word2id, sources)
    sources = conver2id(unk, word2id, sources)
    
#    print("sources ", sources)
#    sources  [[574, 13, 269, 33, 3030, 7, 1141, 606, 128, 66, 7191, 516, 1, 2198, 127, 154, 7071, 4, 287, 13, 140, 3658, 6, 117, 55, 4651, 6137, 16, 68, 5], 
#              [2273, 82, 1635, 15701, 4157, 37, 2936, 30, 29, 28, 1, 416, 16461, 46, 125, 60, 13691, 131, 4, 1270, 160, 2208, 19, 26551, 13, 16217, 6, 73, 16, 5], 
#              [322, 13, 7801, 3847, 37, 2538, 30, 125, 4, 866, 1583, 1627, 848, 11, 23, 208, 3521, 20, 154, 276, 7, 9884, 9, 4, 48, 46, 752, 1236, 3047, 5],
#              ...
#    print("source_binarys ", source_binarys)
#    source_binarys  [[1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
#                     [0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0], 
#                     [1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
#                     ...
    # Convert binary class (above 3 eos): 0->4, 1->5. We will transform back 4->0, 5->1 later in masked decoder loss
#    source_binarys = [[src_bi_num+4 for src_bi_num in src_bi_sent] for src_bi_sent in source_binarys]  
    source_binarys = conver2id(unk, word2id, source_binarys)                                        #   CHANGE IF YOU BINARY SOURCE MASK !
    
    
    source_postags = conver2id(unk, postag2id, source_postags)
    source_deptags = conver2id(unk, deptag2id, source_deptags)
    source_ners = conver2id(unk, nertag2id, source_ners)
    
#    target_binarys = [[tgt_bi_num+4 for tgt_bi_num in tgt_bi_sent] for tgt_bi_sent in target_binarys]
    target_binarys = conver2id(unk, ext_word2id, target_binarys)                                    #   CHANGE IF YOU BINARY TARGET MASK !
    
    
    target_postags = conver2id(unk, postag2id, target_postags)
    
    tar_ins = conver2id(unk, word2id, targets)
    targets = conver2id(unk, ext_word2id, targets)
#    print("source_binarys ", len(source_binarys), source_binarys)
#    l = [len(item) for item in source_binarys]
#    print(l)
#    print("source_postags ", len(source_postags), source_postags)
#    l = [len(item) for item in source_postags]
#    print(l)    
#    print("targets ", len(targets), targets)
#    l = [len(item) for item in targets]
#    print(l)    
#    print("target_postags ", len(target_postags), target_postags)
#    l = [len(item) for item in target_postags]
#    print(l)    
#    a    
    
#    batch = list(zip(sources, src_exts, source_binarys, source_postags, source_deptags, source_ners, tar_ins, targets, target_binarys, target_postags, ext_id2word, sources_words, targets_words))
    batch = (sources, src_exts, source_binarys, source_postags, source_deptags, source_ners, tar_ins, targets, target_binarys, target_postags, ext_id2word, sources_words, targets_words)
    return batch

@curry
def convert_batch_extract_ptr(unk, word2id, batch):
    def convert_one(sample):
        source_sents, extracts = sample
        id_sents = conver2id(unk, word2id, source_sents)
        return id_sents, extracts
    batch = list(map(convert_one, batch))
    return batch

@curry
def convert_batch_extract_ff(unk, word2id, batch):
    def convert_one(sample):
        source_sents, extracts = sample
        id_sents = conver2id(unk, word2id, source_sents)
        binary_extracts = [0] * len(source_sents)
        for ext in extracts:
            binary_extracts[ext] = 1
        return id_sents, binary_extracts
    batch = list(map(convert_one, batch))
    return batch


@curry
def pad_batch_tensorize(inputs, pad, cuda=True):
    """pad_batch_tensorize

    :param inputs: List of size B containing torch tensors of shape [T, ...]
    :type inputs: List[np.ndarray]
    :rtype: TorchTensor of size (B, T, ...)
    """
    tensor_type = torch.cuda.LongTensor if cuda else torch.LongTensor
    batch_size = len(inputs)
    max_len = max(len(ids) for ids in inputs)
    tensor_shape = (batch_size, max_len)
    tensor = tensor_type(*tensor_shape)
    tensor.fill_(pad)
    for i, ids in enumerate(inputs):
        tensor[i, :len(ids)] = tensor_type(ids)
    return tensor

@curry
def batchify_fn(pad, start, end, data, cuda=True):
    sources, targets = tuple(map(list, unzip(data)))

    src_lens = [len(src) for src in sources]
    tar_ins = [[start] + tgt for tgt in targets]
    targets = [tgt + [end] for tgt in targets]

    source = pad_batch_tensorize(sources, pad, cuda)
    tar_in = pad_batch_tensorize(tar_ins, pad, cuda)
    target = pad_batch_tensorize(targets, pad, cuda)

    fw_args = (source, src_lens, tar_in)
    loss_args = (target, )
    return fw_args, loss_args


@curry
def batchify_fn_copy(pad, start, end, data, cuda=True):
    sources, ext_srcs, src_keeps, ext_src_keeps, tar_ins, targets = tuple(map(list, unzip(data)))

    src_lens = [len(src) for src in sources]
    sources = [src for src in sources]
    ext_srcs = [ext for ext in ext_srcs]
    
    # src_keep as input for 2-pass
    src_keep_lens = [len(src) for src in src_keeps]
    src_keeps = [src for src in src_keeps]
    ext_src_keeps = [ext for ext in ext_src_keeps]
    
    src_keeps_tar_ins = [[start] + tgt for tgt in src_keeps]
    ext_src_keeps_targets = [tgt + [end] for tgt in ext_src_keeps]

    # Preparing src_keep as output & input for two passes s2s
    tar_ins = [[start] + tgt for tgt in tar_ins]
    targets = [tgt + [end] for tgt in targets]

    source = pad_batch_tensorize(sources, pad, cuda)
    tar_in = pad_batch_tensorize(tar_ins, pad, cuda)
    target = pad_batch_tensorize(targets, pad, cuda)
    ext_src = pad_batch_tensorize(ext_srcs, pad, cuda)
    
    # src_keep
    src_keep = pad_batch_tensorize(src_keeps, pad, cuda)
    ext_src_keep = pad_batch_tensorize(ext_src_keeps, pad, cuda)
    src_keeps_tar_in = pad_batch_tensorize(src_keeps_tar_ins, pad, cuda)
    ext_src_keeps_target = pad_batch_tensorize(ext_src_keeps_targets, pad, cuda)    

    ext_vsize = ext_src.max().item() + 1
    fw_args = ((source, src_lens, src_keeps_tar_in, ext_src, ext_vsize), (src_keep, src_keep_lens, tar_in, ext_src_keep, ext_vsize))
    loss_args = ((ext_src_keeps_target, ) , (target, ))
    return fw_args, loss_args

@curry
def batchify_fn_copy_operation(pad, start, end, data, cuda=True):
#    sources, ext_srcs, src_binarys, source_postags, source_deptags, source_ners, tar_ins, targets, tgt_binarys, target_postags, ext_id2word, sources_words, targets_words = tuple(map(list, unzip(data)))
    sources, ext_srcs, src_binarys, source_postags, source_deptags, source_ners, tar_ins, targets, tgt_binarys, target_postags, ext_id2word, sources_words, targets_words = data
    
    src_lens = [len(src) for src in sources]
    sources = [src for src in sources]
    ext_srcs = [ext for ext in ext_srcs]
#    print("ext_id2word ", ext_id2word)
    
    # src_binary as output for 1-pass
    source_postags = [src for src in source_postags]
    source_deptags = [src for src in source_deptags]
    source_ners = [src for src in source_ners]
    src_binarys = [src_bi for src_bi in src_binarys]
    tgt_binarys = [tgt_bi + [end] for tgt_bi in tgt_binarys]
    target_postags_ins = [[start] + tgt for tgt in target_postags]
    target_postags = [tgt + [end] for tgt in target_postags]

    # Preparing src_keep as output & input for two passes s2s
    tar_ins = [[start] + tgt for tgt in tar_ins]
    targets = [tgt + [end] for tgt in targets]

    source = pad_batch_tensorize(sources, pad, cuda)
    tar_in = pad_batch_tensorize(tar_ins, pad, cuda)
    target = pad_batch_tensorize(targets, pad, cuda)
    ext_src = pad_batch_tensorize(ext_srcs, pad, cuda)
    
    # src_binary as output for 1-pass
    source_postag = pad_batch_tensorize(source_postags, pad, cuda)
    source_deptag = pad_batch_tensorize(source_deptags, pad, cuda)
    source_ner = pad_batch_tensorize(source_ners, pad, cuda)
    target_postags_in = pad_batch_tensorize(target_postags_ins, pad, cuda)
    target_postag = pad_batch_tensorize(target_postags, pad, cuda)
    src_binary = pad_batch_tensorize(src_binarys, pad, cuda)    
    tgt_binary = pad_batch_tensorize(tgt_binarys, pad, cuda)    
#    print("src_binary ", src_binary.size(), src_binary)
#    print("source_postag ", source_postag.size(), source_postag)
#    print("target ", target.size(), target)
#    print("target_postag ", target_postag.size(), target_postag)
#    a

    ext_vsize = ext_src.max().item() + 1
    fw_args = (source, src_lens, tar_in, ext_src, ext_vsize, source_postag, source_deptag, source_ner, target_postags_in, src_binary, ext_id2word, sources_words, targets_words) # process source_postag_target_in = [start] + tgt later
    loss_args = ((src_binary, ), (source_postag, ), (target, ), (tgt_binary, ), (target_postag, ))
    return fw_args, loss_args


@curry
def batchify_fn_extract_ptr(pad, data, cuda=True):
    source_lists, targets = tuple(map(list, unzip(data)))

    src_nums = list(map(len, source_lists))
    sources = list(map(pad_batch_tensorize(pad=pad, cuda=cuda), source_lists))

    # PAD is -1 (dummy extraction index) for using sequence loss
    target = pad_batch_tensorize(targets, pad=-1, cuda=cuda)
#    remove_last = lambda tgt: tgt[:-1] # why do we remove the last sentence of target ? Questioned in the forum as well
    def remove_last(tgt):
        tgt[1:] = tgt[:-1]
        return tgt    
    
#    print("target size ", target.size())
    tar_in = pad_batch_tensorize(
        list(map(remove_last, targets)), # error in sequence_loss : assert logits.size()[:-1] == targets.size()
        pad=-0, cuda=cuda # use 0 here for feeding first conv sentence repr.
    )
#    print("tar_in size ", tar_in.size())

    fw_args = (sources, src_nums, tar_in)
    loss_args = (target, )
    return fw_args, loss_args

@curry
def batchify_fn_extract_ff(pad, data, cuda=True):
    source_lists, targets = tuple(map(list, unzip(data)))

    src_nums = list(map(len, source_lists))
    sources = list(map(pad_batch_tensorize(pad=pad, cuda=cuda), source_lists))

    tensor_type = torch.cuda.FloatTensor if cuda else torch.FloatTensor
    target = tensor_type(list(concat(targets)))

    fw_args = (sources, src_nums)
    loss_args = (target, )
    return fw_args, loss_args


def _batch2q(loader, prepro, q, single_run=True):
    epoch = 0
    while True:
        for batch in loader:
            q.put(prepro(batch))
        if single_run:
            break
        epoch += 1
        q.put(epoch)
    q.put(None)

class BucketedGenerater(object):
    def __init__(self, loader, prepro,
                 sort_key, batchify,
                 single_run=True, queue_size=8, fork=True):
        self._loader = loader
        self._prepro = prepro
        self._sort_key = sort_key
        self._batchify = batchify
        self._single_run = single_run
        if fork:
            ctx = mp.get_context('forkserver')
            self._queue = ctx.Queue(queue_size)
        else:
            # for easier debugging
            self._queue = None
        self._process = None

    def __call__(self, batch_size: int):
        def get_batches(hyper_batch):
            indexes = list(range(0, len(hyper_batch), batch_size))
            if not self._single_run:
                # random shuffle for training batches
                random.shuffle(hyper_batch)
                random.shuffle(indexes)
            hyper_batch.sort(key=self._sort_key, reverse=True)
            for i in indexes:
                batch = self._batchify(hyper_batch[i:i+batch_size])
                yield batch

        if self._queue is not None:
            ctx = mp.get_context('forkserver')
            self._process = ctx.Process(
                target=_batch2q,
                args=(self._loader, self._prepro,
                      self._queue, self._single_run)
            )
            self._process.start()
            while True:
                d = self._queue.get()
                if d is None:
                    break
                if isinstance(d, int):
                    print('\nepoch {} done'.format(d))
                    continue
                yield from get_batches(d)
            self._process.join()
        else:
            i = 0
            while True:
                for batch in self._loader:
                    yield from get_batches(self._prepro(batch))
                if self._single_run:
                    break
                i += 1
                print('\nepoch {} done'.format(i))

    def terminate(self):
        if self._process is not None:
            self._process.terminate()
            self._process.join()
