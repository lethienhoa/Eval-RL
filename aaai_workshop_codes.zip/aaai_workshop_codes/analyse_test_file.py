import os
from os.path import exists, join
import json
import tarfile
import io
from corenlpy import AnnotatedText as A # https://github.com/enewe101/corenlpy
import copy
import sys
reload(sys)
sys.setdefaultencoding('utf8')

from stanfordcorenlp import StanfordCoreNLP # https://github.com/Lynten/stanford-corenlp
import time

port = 5000

class StanfordNLP:
    def __init__(self, host='http://localhost', port=port):
        self.nlp = StanfordCoreNLP(host, port=port,
                                   timeout=100000)  # , quiet=False, logging_level=logging.DEBUG)
        self.props = {
            'annotators': 'tokenize,ssplit,pos,lemma,ner,parse,depparse,openie',
            'pipelineLanguage': 'en',
            'outputFormat': 'xml',
#            'outputFormat': 'json'
        }

    def annotate(self, sentence):
#        return json.loads(self.nlp.annotate(sentence, properties=self.props))
        return self.nlp.annotate(sentence, properties=self.props)
        
sNLP = StanfordNLP()
#print("port ", port)


# Write to JSON file

namefile = 'gold_abstract'
    
file_in = open('/home/hoa/fast_abs_rl/delete_paraphrase/analyse_results/' + namefile, 'r').readlines()
file_out = open('/home/hoa/fast_abs_rl/delete_paraphrase/analyse_results/statspos_' + namefile, 'w')

# Read lines of article file
for idx in range(0, 1951): 
    print(idx)
        
    annotated_text = A(sNLP.annotate(file_in[idx].replace("\n",""))) # get annotated format XML file to object
    sentences = annotated_text.sentences        
    postag = []
    for sentence in sentences: # ['tokens', 'entities', 'references', 'mentions', 'root', 'id']
        for word in sentence['tokens']:
            postag.append(word['pos'])
    file_out.write(" ".join(postag) + "\n")

file_in.close()
file_out.close()
    
      
