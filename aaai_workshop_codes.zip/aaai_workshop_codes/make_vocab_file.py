"""produce the dataset with (psudo) extraction label"""
import os
from os.path import exists, join
import json
from time import time
from datetime import timedelta
import multiprocessing as mp
import collections
import pickle as pkl

from cytoolz import curry, compose

from utils import count_data
from metric import compute_rouge_l, compute_rouge_n


try:
    DATA_DIR = '/home/hoa/fast_abs_rl/data_SDparsing/JSONdata/'
except KeyError:
    print('please use environment variable to specify data directories')


def label(split):
    print('start processing {} split...'.format(split))
    data_dir = join(DATA_DIR, split)
    n_data = count_data(data_dir)
    
    vocab_counter = collections.Counter()
        
    for i in range(n_data):
        print('processing {}/{} ({:.2f}%%)\r'.format(i, n_data, 100*i/n_data),
              end='')
        with open(join(data_dir, '{}.json'.format(i))) as f:
            data = json.loads(f.read())
            
        # Build train vocab
        art_tokens = ' '.join([data['source_constituencytag']]).split()
        abs_tokens = ' '.join(data['abstract_constituencytag']).split()
        tokens = art_tokens + abs_tokens
        tokens = [t.strip().lower() for t in tokens] # strip
        tokens = [t for t in tokens if t != ""] # remove empty
        vocab_counter.update(tokens)
    
    # write vocab to file
    print("Writing vocab file...")
    with open(os.path.join(DATA_DIR, "vocab_constituency_cnt.pkl"),
              'wb') as vocab_file:
        pkl.dump(vocab_counter, vocab_file)
    print("Finished writing vocab file")   


def main():
    label('96k_train_del_para')
#    for split in ['val','train']:  # no need of extraction label when testing
#        label_mp(split)

if __name__ == '__main__':
    main()
