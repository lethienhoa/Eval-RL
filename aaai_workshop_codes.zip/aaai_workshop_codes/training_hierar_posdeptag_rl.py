""" module providing basic training utilities"""
import os
from os.path import join
from time import time
from datetime import timedelta
from itertools import starmap

from cytoolz import curry, reduce
from cytoolz import concat
from math import exp

from utils import PAD, UNK, START, END
from data.batcher_gen_postag import conver2id, pad_batch_tensorize
import torch
from torch.nn.utils import clip_grad_norm_
from torch.optim.lr_scheduler import ReduceLROnPlateau
import tensorboardX
from metric import compute_rouge_l, compute_rouge_n
import json
from torch.nn import functional as F

def convert_ids_to_words(decs, attns, ext_id2word, sources_words): # we use sources_words (not ext_id2word(sources_id)) because we want to get rid of <pad> token & still keep low-frequency (oov words)
#        print("sources_words", len(sources_words), sources_words)
#        sources_words 32 
#        [['phil', 'simmons', 'took', 'over', 'leicestershire', 'captaincy', 'and', 'saw', 'his', 'side', 'to', 'run', 'sunday', 'league', 'win'], 
#         ['###', 'people', 'rallied', 'thursday', 'in', 'center', 'of', 'serbian', 'capital', 'belgrade', 'in', 'support', 'of', 'teachers', 'strike'],        
#          ...
#        print("decs", decs.size(), decs)
#        decs torch.Size([32, 9]) 
#        tensor([[  4519,  14296,      1,      3,      3,      3,      3,      3,     3],
#                [  1285,     13,      3,      3,      3,      3,      9,     15,     99],
#                [ 12049,     65,    214,      3,      3,      3,      3,      3,     3],
#                ...
#        print("attns[0]", attns[0].size(), attns[0])
#        attns[0] torch.Size([32, 16]) (each column tokens on padding target corresponds to [32 x 16] padding source). Note: attn on padding token of source will be equal to 0.
#        tensor([[ 0.2480,  0.1061,  0.1709,  0.1005,  0.0635,  0.0761,  0.0045, 0.0462,  0.0049,  0.0392,  0.0112,  0.0416,  0.0220,  0.0599,  0.0056,  0.0000],
#                [ 0.0394,  0.0034,  0.0041,  0.0050,  0.0138,  0.3446,  0.0011, 0.0478,  0.0081,  0.4555,  0.0010,  0.0020,  0.0018,  0.0359,  0.0366,  0.0000],
#                ...
#        print("attns[1]", attns[1].size(), attns[1])
#        attns[1] torch.Size([32, 16]) 
#        tensor([[ 0.0036,  0.3302,  0.3075,  0.2650,  0.0169,  0.0382,  0.0141,  0.0150,  0.0005,  0.0021,  0.0012,  0.0007,  0.0035,  0.0013,  0.0001,  0.0000],
#                [ 0.1138,  0.0233,  0.1254,  0.0271,  0.0409,  0.0062,  0.0365,  0.0850,  0.0184,  0.0261,  0.1303,  0.0260,  0.0749,  0.1038,  0.1622,  0.0000],
#                ...
#        print("attns", len(attns), attns)
#        attns 9 (9 column tokens on padding target)
#        [
#            tensor([[ 0.2480,  0.1061,  0.1709,  0.1005,  0.0635,  0.0761,  0.0045, 0.0462,  0.0049,  0.0392,  0.0112,  0.0416,  0.0220,  0.0599,  0.0056,  0.0000],
#                    [ 0.0394,  0.0034,  0.0041,  0.0050,  0.0138,  0.3446,  0.0011, 0.0478,  0.0081,  0.4555,  0.0010,  0.0020,  0.0018,  0.0359,  0.0366,  0.0000],
#                    ...
#            tensor([[ 0.0036,  0.3302,  0.3075,  0.2650,  0.0169,  0.0382,  0.0141,  0.0150,  0.0005,  0.0021,  0.0012,  0.0007,  0.0035,  0.0013,  0.0001,  0.0000],
#                    [ 0.1138,  0.0233,  0.1254,  0.0271,  0.0409,  0.0062,  0.0365,  0.0850,  0.0184,  0.0261,  0.1303,  0.0260,  0.0749,  0.1038,  0.1622,  0.0000],
#                    ...        
    dec_sents = []
    cnt_row = 0
    for raw_words, id_ in zip(sources_words, decs): 
        words = []
        for cnt_col in range(decs.size(1)):
            if id_[cnt_col] == END:
                break # we stop when we see <eos> token (computing rouge), even at training time
            elif id_[cnt_col] == UNK:
#                    print("raw_words", raw_words)
#                    print("id_", id_)
#                    print("attns[cnt_col][cnt_row])", attns[cnt_col][cnt_row])
#                    print("raw_words[torch.argmax(attns[cnt_col][cnt_row])]", raw_words[torch.argmax(attns[cnt_col][cnt_row])])
                words.append(raw_words[torch.argmax(attns[cnt_col][cnt_row])]) 
                # in case if still have UNK token, replace it by token of argmax idx from source attn
                # raw_words : 1d vector variable length of source, for ex: [1..15 or 16].  attn[i]: [32, 16 fixed]
            else:
                words.append(ext_id2word[id_[cnt_col].item()])
        dec_sents.append(words)
        cnt_row += 1
#        print("dec_sents", len(dec_sents), dec_sents)       
    return dec_sents   

def avg_loss_logit_masked_sent_fn(target_sent, logit_sampling_sent): # target_tokens_id & logit mask still keep <pad> (but Rouge doesn't) because we need the model to learn prob mass of this token comparing to ground-truth, so that at test time, we will stop when we first see it)
    # Use ground-truth target to mask
#            print("bw_args", bw_args)
#            print("sampling_token", sampling_token)
#            print("greedy_token", greedy_token)
#            print("sampling_token[sent,:]", sampling_token[sent,:])
#            print("greedy_token[sent,:]", greedy_token[sent,:])            
    mask = target_sent != PAD # after <eos> (index 3), we pad it (index 0)
#            print("bw_args[0][sent]", bw_args[0][sent]) # vector 1d [8 elements]
#            print("mask", mask)                       # vector 1d [8 elements]
    target_masked_sent = target_sent.masked_select(mask) # vector 1d: for ex [7 elements]
#            print("target_masked_sent", target_masked_sent.size(), target_masked_sent)
    logit_sampling_sent = logit_sampling_sent.squeeze(0) # logit_sampling: [32, 8 tokens, 30005], logit_sampling_sent[1, 8, 30005] to [8, 30005]
#            print("logit_sampling_sent", logit_sampling_sent.size(), logit_sampling_sent)
#            mask.unsqueeze(1) # [8 x 1]
#            mask.unsqueeze(1).expand_as(logit_sampling_sent) # [8 x 30005]
    logit_sampling_masked_sent = logit_sampling_sent.masked_select(
                mask.unsqueeze(1).expand_as(logit_sampling_sent)  # all of this will result in a very long vector, for ex: [703829 elements]
            ).contiguous().view(-1, logit_sampling_sent.size(-1)) # transform 1d very long very vector to 2d, for ex: [7 x 30005]
#            print("logit_sampling_masked_sent", logit_sampling_masked_sent.size(), logit_sampling_masked_sent)
    result = F.nll_loss(logit_sampling_masked_sent, target_masked_sent, reduce=False).mean()    
#        print("result", result)
    
    return result

def get_basic_grad_fn(net, clip_grad, max_grad=1e2):
    def f():
        grad_norm = clip_grad_norm_(
            [p for p in net.parameters() if p.requires_grad], clip_grad)
        grad_norm = grad_norm.item()
        if max_grad is not None and grad_norm >= max_grad:
            print('WARNING: Exploding Gradients {:.2f}'.format(grad_norm))
            grad_norm = max_grad
        grad_log = {}
        grad_log['grad_norm'] = grad_norm
        return grad_log
    return f

@curry
def compute_loss(net, criterion, typenet, fw_args, loss_args):

#    print(typedataset)
    
    logit_source_binary, logit_source_postag, logit_final, \
    (logit_sampling, sampling_token, logit_greedy, greedy_token, attn, ext_id2word, sources_words, targets_words), \
    logit_target_postag, copy_prob, logit_source_enc_postag = net(*fw_args)  # here is net_out1 = (3D tensor, )
    source_binary_gold, source_postag_gold, abstract_gold, target_binary_gold, target_postag_gold = loss_args
    
    def compute_loss_fact(net_out, loss_args_tmp, task):
        if isinstance(net_out, tuple):
            loss_args_tmp = net_out + loss_args_tmp # net_out is a tuple: (net_out logit, coverage_loss) here. concatenate tuple (not adding)
        else:
            loss_args_tmp = (net_out, ) + loss_args_tmp # concatenate tuple (not adding)
        #loss = criterion(*((net(*fw_args),) + loss_args)) # Running abstractor step 8: compute dev loss
        loss_tmp = criterion(*loss_args_tmp, task) # Step 8: evaluate
        return loss_tmp
    
#    loss1 = compute_loss_fact(logit_source_binary, source_binary_gold, task="delete_encoder")  # here is net_out1 = (3D tensor, ) # too small value (binary loss value) => leads to exploding gradient ? How to normalize ?
    loss2 = compute_loss_fact(logit_final, abstract_gold, task="normal") # too big value (result of a big network on 30k classes): value of 8 times (4.4371 / 0.5542): how to guess this value ?
#    loss4 = compute_loss_fact(logit_source_enc_postag, source_postag_gold, task="postag")
#    loss5 = compute_loss_fact(logit_target_postag, target_postag_gold, task="postag")
#    print("loss1 ", loss1)
#    loss1  tensor([-0.4689, -0.5416, -0.5283,  ..., -0.5492, -0.5442, -0.5658], device='cuda:0')
#    print("loss2 ", loss2)
#    a
#    loss2  tensor([  4.1285,   4.4743,   4.3861,   9.6259,   4.4371,   4.5138,   14.3922,   9.7793,  12.5512,   2.0409,  11.4138,  11.5864,    
#    loss = torch.cat((loss1, loss2, loss4, loss5), dim=0) # concatenate 2 tensors (not 2 lists python)
#    loss = torch.cat((loss5, loss2), dim=0)
    loss = loss2
#    print("loss ", loss)
    
    return loss

@curry
def val_step(loss_step, fw_args, loss_args): # Running abstractor step 7: evaluate dev set
    loss = loss_step(fw_args, loss_args)
    return loss.size(0), loss.sum().item()

@curry
def basic_validate(net, criterion, val_batches, typenet="net"):
#    print('running validation ... ', end='')
    net.eval()
#    net2.eval()
#    start = time()
    with torch.no_grad():
        validate_fn = val_step(compute_loss(net, criterion, typenet)) # Running abstractor step 6: evaluate dev set
        n_data, tot_loss = reduce(
            lambda a, b: (a[0]+b[0], a[1]+b[1]),
            starmap(validate_fn, val_batches),
            (0, 0)
        )
    val_loss = tot_loss / n_data
#    print(
#        'validation finished in {}                                    '.format(
#            timedelta(seconds=int(time()-start)))
#    )
    print('{:s} - Val Loss: {:.4f} ...'.format(typenet, val_loss))
    return {'loss': val_loss}


class BasicPipeline(object):
    def __init__(self, name, net,
                 train_batcher, val_batcher, test_batcher, batch_size,
                 val_fn, criterion, optim, word2id, postag2id, deptag2id, nertag2id, grad_fn=None,):
        self.name = name
        self._net = net
        self._train_batcher = train_batcher
        self._val_batcher = val_batcher
        self._test_batcher = test_batcher
        self._criterion = criterion
        self._opt = optim
        # grad_fn is calleble without input args that modifyies gradient
        # it should return a dictionary of logging values
        self._grad_fn = grad_fn
        self._val_fn = val_fn

        self._n_epoch = 0  # epoch not very useful?
        self._batch_size = batch_size
        self._batches = self.batches()
        cuda = True
        self._device = torch.device('cuda' if cuda else 'cpu')
        self._word2id = word2id
        self._postag2id = postag2id
        self._deptag2id = deptag2id
        self._nertag2id = nertag2id
        self._id2word = {i: w for w, i in word2id.items()}
        self._max_len = 30 # generate maximum 30 words on abstract

    def batches(self):
        while True:
            for fw_args, bw_args in self._train_batcher(self._batch_size):
                yield fw_args, bw_args
            self._n_epoch += 1

    def get_loss_args(self, net_out, bw_args):
        if isinstance(net_out, tuple):
            loss_args = net_out + bw_args # net_out is a tuple: (net_out logit, coverage_loss) here. concatenate tuple (not adding)
        else:
#            print("net_out size", net_out.size())
#            print("bw_args", bw_args)
            loss_args = (net_out, ) + bw_args # concatenate tuple (not adding)
        return loss_args

    def train_step(self, step):
        # forward pass of model
        self._net.train()
        fw_args, bw_args = next(self._batches)
        source_binary_gold, source_postag_gold, abstract_gold, target_binary_gold, target_postag_gold = bw_args

        logit_source_binary, logit_source_postag, logit_final, \
        (logit_sampling, sampling_token, logit_greedy, greedy_token, attn, ext_id2word, sources_words, targets_words), \
        logit_target_postag, copy_prob, logit_source_enc_postag = self._net(*fw_args)
        
        # Coverage step 4a. Coverage loss
#        coverage_loss = None
#        if isinstance(net_out, tuple): # is_coverage = True
#            net_out, coverage_loss = net_out
#            print("coverage_loss size", coverage_loss.size())
#        print("net_out size", net_out.size())

        # get logs and output for logging, backward
        log_dict = {}
        
#        log_dict['loss'] = 0
#        return log_dict
        
#        loss_args5 = self.get_loss_args(logit_target_postag, target_postag_gold)
#        loss_args4 = self.get_loss_args(logit_source_enc_postag, source_postag_gold)
        loss_args2 = self.get_loss_args(logit_final, abstract_gold)
#        loss_args1 = self.get_loss_args(logit_source_binary, source_binary_gold)
#        print("bw_args", bw_args)
#        print("bw_args size", bw_args.size())
#        print("loss_args 0 size", loss_args[0].size())
#        print("loss_args 1 size", loss_args[1].size())
#        print("loss_args 2 size", loss_args[2].size())

        # backward and update ( and optional gradient monitoring )
        loss_ml = self._criterion(*loss_args2, task="normal").mean()
#        loss1 = self._criterion(*loss_args1, task="delete_encoder").mean() # Running abstractor step 2: compute training loss
#        loss5 = self._criterion(*loss_args5, task="postag").mean()
#        loss4 = self._criterion(*loss_args4, task="postag").mean()        
        
##        # RL loss (with logit conditioned on sampling tokens)
        loss_rl = torch.tensor(0.)
        loss_rl = loss_rl.cuda()

        # 1. transform sampling_token, greedy_token to word & compute rouge
        # Copy pointer use (different) ext_id2word for each mini-batch
        # For ROUGE: remove <pad> token even during training time (Note: it's opposed to NLL, we need the model to learn prob mass of this token comparing to ground-truth, so that at test time, we will stop when we first see it)
#        print("greedy_token ", greedy_token.size(), greedy_token)
#        print("attn ", attn)
#        print("ext_id2word ", ext_id2word)
#        print("sources_words ", sources_words)
        words_pred_greedy = convert_ids_to_words(greedy_token, attn, ext_id2word, sources_words)
#        print("words_pred_greedy", words_pred_greedy)
        words_pred_sampling = convert_ids_to_words(sampling_token, attn, ext_id2word, sources_words)
#        print("words_pred_sampling", words_pred_sampling)    
        
        for sent in range(abstract_gold[0].size()[0]):
            # Compute rl_loss for each sentence in mini-batch:
            # 2. mask logit_sampling, compute avg logit for each sentence
            avg_loss_logit_sampling_masked_sent = avg_loss_logit_masked_sent_fn(abstract_gold[0][sent], logit_sampling[sent,:,:]) # bw_args[0][sent] !!!!
#            print("avg_loss_logit_sampling_masked_sent", avg_loss_logit_sampling_masked_sent)
        
            # compute rouge for each sentence
            # ROUGE
            metric_greedy_sent = compute_rouge_n(words_pred_greedy[sent], targets_words[sent], n=2) # we need to feed raw target words here (not id2word of target_ids) as we want to compare to ground-truth (ground-truth target can contain low-frequency words)
#            print("words_pred_greedy[sent]", words_pred_greedy[sent])
#            print("targets_words[sent]", targets_words[sent])
#            print("metric_greedy_sent", metric_greedy_sent)
#            print("words_pred_sampling[sent]", words_pred_sampling[sent]) # Diverge: no sampling tokens here (because cosine can be negative ?) (source or target have the same problem)
            
            # ROUGE
            metric_sampling_sent = compute_rouge_n(words_pred_sampling[sent], targets_words[sent], n=2)
#            print("metric_sampling_sent", metric_sampling_sent)
#            a
            
            # Equation 15 of https://arxiv.org/abs/1705.04304
            loss_rl += (metric_greedy_sent - metric_sampling_sent) * avg_loss_logit_sampling_masked_sent
#            print("loss_rl", loss_rl)
        
        loss_rl /= abstract_gold[0].size()[0] # avg loss_rl over minibatch size
#        print("loss_rl", loss_rl)
#        print("loss_ml", loss_ml)
        
        
        # Mixed loss
#        gamma = torch.tensor(0.)
#        gamma = torch.tensor(0.68)
        gamma = torch.min(torch.FloatTensor([step/100000, 0.42])) # after 100.000 batches, we will only train with RL loss
        gamma = gamma.cuda()
#        print("gamma, _step", gamma, _step)
#        print("gamma ", gamma)
#        print("loss_rl ", loss_rl)
#        print("loss_ml ", loss_ml)
#        a

        # Equation 16 of https://arxiv.org/abs/1705.04304
        loss2 = gamma * loss_rl + (1 - gamma) * loss_ml
#        print("loss ", loss)
#        if step % 3000 == 0:
#            print("\nStep: ", step, "loss_rl: ", round(loss_rl.item(),2), ", gamma: ", round(gamma.item(),4), ", loss_ml: ", 
#                  round(loss_ml.item(),2), ", loss: ",  round(loss2.item(),2))      
#            print("Loss s2s, target_postag: ", loss2, loss5)
        
#        print("loss1 ", loss1)
#        loss1  tensor(0.6949, device='cuda:0')
#        print("loss2 ", loss2)
#        loss2  tensor(7.7497, device='cuda:0')
#        a
        
        # alternate loss or sum loss ?
#        loss = loss5 + loss4 + loss2 + loss1 
#        k = 1500
#        print(k)
#        coeff = k/(k+exp(step/k)) # Inverse sigmoid decay
#        print(coeff)
#        coeff = torch.cuda.FloatTensor([coeff])[0]
#        print(coeff, loss2, loss4, loss5)
        loss = loss2 # + loss5 # + loss4
#        print(loss)
#        a
#        loss = loss2
        loss.backward()
        
        log_dict['loss'] = loss.item() # only log first loss1
        if self._grad_fn is not None:
            log_dict.update(self._grad_fn())
        self._opt.step()
        self._net.zero_grad()

        return log_dict
    
    def validate(self):
#        print("Test set performance: ")
        listargs = {}
        listargs['_word2id'] = self._word2id
        listargs['_id2word'] = self._id2word
        listargs['_postag2id'] = self._postag2id
        listargs['_deptag2id'] = self._deptag2id
        listargs['_nertag2id'] = self._nertag2id
#        print("listargs['_id2word']", listargs['_id2word'])
        listargs['_device'] = self._device
        listargs['_max_len'] = self._max_len
        test_performance(self._net, self._test_batcher, listargs)
        
#        print("Val set loss: ")
        # Same total loss for 2 schedulers (or each loss for each scheduler ?)
        val_log1 = self._val_fn(self._val_batcher(self._batch_size), "net")
        print("\n")
        return val_log1 # Running abstractor step 5: evaluate

    def checkpoint(self, save_path, step, val_metric=None):
        save_dict = {}
        if val_metric is not None:
            name = 'ckpt-{:6f}-{}'.format(val_metric, step)
            save_dict['val_metric'] = val_metric
        else:
            name = 'ckpt-{}'.format(step)

        save_dict['state_dict'] = self._net.state_dict()
        save_dict['optimizer'] = self._opt.state_dict()
        torch.save(save_dict, join(save_path, name))

    def terminate(self):
        self._train_batcher.terminate()
        self._val_batcher.terminate()

def _prepro(raw_article_sents, raw_source_postag_sents, raw_source_deptag_sents, raw_source_nertag_sents, listargs): # is it ok to do like this ?
    ext_word2id = dict(listargs['_word2id'])
    ext_id2word = dict(listargs['_id2word'])
    for raw_words in raw_article_sents:
        for w in raw_words:
            if not w in ext_word2id:
                ext_word2id[w] = len(ext_word2id)
                ext_id2word[len(ext_id2word)] = w
    articles = conver2id(UNK, listargs['_word2id'], raw_article_sents)
    articles_postag = conver2id(UNK, listargs['_postag2id'], raw_source_postag_sents)
    articles_deptag = conver2id(UNK, listargs['_deptag2id'], raw_source_deptag_sents)
    articles_nertag = conver2id(UNK, listargs['_nertag2id'], raw_source_nertag_sents)
    art_lens = [len(art) for art in articles]
#    print("raw_article_sents ", raw_article_sents)
#    print("art_lens ", art_lens)
    article = pad_batch_tensorize(articles, PAD, cuda=False
                                 ).to(listargs['_device'])
    article_postag = pad_batch_tensorize(articles_postag, PAD, cuda=False
                                 ).to(listargs['_device'])    
    article_deptag = pad_batch_tensorize(articles_deptag, PAD, cuda=False
                                 ).to(listargs['_device'])  
    article_nertag = pad_batch_tensorize(articles_nertag, PAD, cuda=False
                                 ).to(listargs['_device'])      
    extend_arts = conver2id(UNK, ext_word2id, raw_article_sents)
    extend_art = pad_batch_tensorize(extend_arts, PAD, cuda=False
                                    ).to(listargs['_device'])
    extend_vsize = len(ext_word2id)
        
    dec_args = (article, art_lens, extend_art, extend_vsize, article_postag, article_deptag, article_nertag,
                START, END, UNK, listargs['_max_len'])
#    print("dec_args", dec_args)
#    a
    return dec_args, ext_id2word

def abstractor_decode(net, raw_article_sents, raw_source_postag_sents, raw_source_deptag_sents, raw_source_nertag_sents, listargs):
    
#        self._net.eval() # eval ? (not training ?) => there's no loss (with coverage loss here) ? No abstractor learning finetune here ? only use pretrained extractor & abstractor parameters to learn RL extractor ?
    
    dec_args, id2word = _prepro(raw_article_sents, raw_source_postag_sents, raw_source_deptag_sents, raw_source_nertag_sents, listargs)
    decs, attns, coverage = net.batch_decode(*dec_args) # Running full step 4. call CopySumm abstractor batch_decode (we have extracted sentences by RL)
    def argmax(arr, keys):
        return arr[max(range(len(arr)), key=lambda i: keys[i].item())]
    dec_sents = []
    for i, raw_words in enumerate(raw_article_sents):
        dec = []
        for id_, attn in zip(decs, attns):
            if id_[i] == END:
                break
            elif id_[i] == UNK:
                dec.append(argmax(raw_words, attn[i]))
            else:
                dec.append(id2word[id_[i].item()])
        dec_sents.append(dec)
    return dec_sents  
    
def test_performance(net, loader, listargs):
    net.eval()
    avg_reward1 = 0
    avg_reward2 = 0
    avg_rewardL = 0     
    i = 0
    with torch.no_grad():
        for art_batch, source_binary_batch, source_postag_batch, source_deptag_batch, source_nertag_batch, \
                abstract_batch, abstract_binary_batch, abstract_postag_batch in loader: 
            art_batch = [article[0] for article in art_batch] # art_batch: 32 sentences (list of raw words)
            source_postag_batch = [src[0] for src in source_postag_batch]
            source_deptag_batch = [src[0] for src in source_deptag_batch]
            source_nertag_batch = [src[0] for src in source_nertag_batch]
            abstract_batch = [abstract[0] for abstract in abstract_batch]

            abstract_gen = abstractor_decode(net, art_batch, source_postag_batch, source_deptag_batch, source_nertag_batch, listargs)
#            print("art_batch ", art_batch)
#            print("abstract_gen ", abstract_gen)
#            print("abstract_batch ", abstract_batch)
#            a
#            print("list(concat(abstract_gen))", list(concat(abstract_gen)))
#            print(i, " - ", len(art_batch), " - ", len(source_keep_gen), " - ", len(abstract_gen))
            # compute rouge: visit each sentence in batch 32
            for j in range(len(abstract_batch)):
#                print(" ".join(abstract_gen[j]))
#                print("abstract_gen[j]", abstract_gen[j])
#                print("abstract_batch[j]", abstract_batch[j])
                tmp_r1 = compute_rouge_n(abstract_gen[j],              # That's why it can choose more than 1 source sentence here
                                        abstract_batch[j], n=1)
                tmp_r2 = compute_rouge_n(abstract_gen[j],              # That's why it can choose more than 1 source sentence here
                                         abstract_batch[j], n=2)
                tmp_rL = compute_rouge_l(abstract_gen[j],              # That's why it can choose more than 1 source sentence here
                                         abstract_batch[j])    
                avg_reward1 += tmp_r1
                avg_reward2 += tmp_r2
                avg_rewardL += tmp_rL
                i += 1
#    print("art_batch ", art_batch)
#    print("abstract_gen ", abstract_gen)
#    print("abstract_batch ", abstract_batch)
        
    avg_reward1 /= (i/100)
    avg_reward2 /= (i/100)
    avg_rewardL /= (i/100)        

    print('\nTest Delete-and-Paraphrase rouge-1: {:.2f}, rouge-2: {:.2f}, rouge-L: {:.2f}'.format(avg_reward1, avg_reward2, avg_rewardL))        
#    a

class BasicTrainer(object):
    """ Basic trainer with minimal function and early stopping"""
    def __init__(self, pipeline, save_dir, ckpt_freq, patience,
                 scheduler=None, val_mode='loss'):
        assert isinstance(pipeline, BasicPipeline)
        assert val_mode in ['loss', 'score']
        self._pipeline = pipeline
        self._save_dir = save_dir
        self._logger = tensorboardX.SummaryWriter(join(save_dir, 'log'))
        if not os.path.isdir(join(save_dir, 'ckpt')):
            os.makedirs(join(save_dir, 'ckpt'))

        self._ckpt_freq = ckpt_freq
        self._patience = patience
        self._sched = scheduler
        self._val_mode = val_mode

        self._step = 0
        self._running_loss = None
        # state vars for early stopping
        self._current_p = 0
        self._best_val = None

    def log(self, log_dict):
        loss = log_dict['loss'] if 'loss' in log_dict else log_dict['reward'] # only use loss1 to log out
        if self._running_loss is not None:
            self._running_loss = 0.99*self._running_loss + 0.01*loss
        else:
            self._running_loss = loss
        print('train step: {}, {}: {:.4f}\r'.format(
            self._step,
            'loss' if 'loss' in log_dict else 'reward',
            self._running_loss), end='')
        for key, value in log_dict.items():
            self._logger.add_scalar(
                '{}_{}'.format(key, self._pipeline.name), value, self._step)

    def validate(self):
        val_log1 = self._pipeline.validate() # Running abstractor step 4: evaluate
        
        def get_val_metric(val_log):
            for key, value in val_log.items():
                self._logger.add_scalar(
                    'val_{}_{}'.format(key, self._pipeline.name),
                    value, self._step
                )
            if 'reward' in val_log:
                val_metric = val_log['reward']
            else:
                val_metric = (val_log['loss'] if self._val_mode == 'loss'
                              else val_log['score'])
            return val_metric
        
        val_metric1 = get_val_metric(val_log1)
        
        return val_metric1

    def checkpoint(self):
        val_metric1 = self.validate() # Running abstractor step 3: evaluate dev set (at 3k step)
        self._pipeline.checkpoint(
            join(self._save_dir, 'ckpt'), self._step, val_metric1)  # only use val_metric1 to log out
        if isinstance(self._sched, ReduceLROnPlateau):
            self._sched.step(val_metric1)
        else:
            self._sched.step()
        stop = self.check_stop(val_metric1) # only use val_metric1 to check_stop
        return stop

    def check_stop(self, val_metric):
        if self._best_val is None:
            self._best_val = val_metric
        elif ((val_metric < self._best_val and self._val_mode == 'loss')
              or (val_metric > self._best_val and self._val_mode == 'score')):
            self._current_p = 0
            self._best_val = val_metric
        else:
            self._current_p += 1
        return self._current_p >= self._patience

    def train(self):
        try:
            start = time()
            print('Start training')
            while True:
                log_dict = self._pipeline.train_step(self._step) # Running abstractor - full rl step 1: train
                self._step += 1
                self.log(log_dict)

                if self._step % self._ckpt_freq == 0:
                    stop = self.checkpoint() # Running abstractor step 2b: call checkpoint (at 3k step) (evaluate on dev set)
                    if stop:
                        break
            print('Training finised in ', timedelta(seconds=time()-start))
        finally:
            self._pipeline.terminate()
